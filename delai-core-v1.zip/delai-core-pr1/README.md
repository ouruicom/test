# delai-core · 核心逻辑成品

> **一个包、一次收口。** 已知缺陷全部关闭，不再分批出 PR 包。
> `tsc --noEmit` **0 错误** · 基线门禁 PASS · **31 条验收全绿 / 0 fail / 0 todo** · 静态扫描 PASS。

## 三条命令（Win11 PowerShell 分三行粘贴，别用 `&&`）

```bash
node scripts/typecheck-gate.mjs
node scripts/build.mjs
node --test dist/test/*.test.js
```

自带 TypeScript 5.6.3 编译器（`tools/ts/lib/`），**不用 npm install**，Node ≥ 20 即可。
本机装了 npm 时等价：`npm run check`。

## 这个包是什么

把 `plan-v1.8.md` 里散落的 TypeScript 片段搬进可编译目录，并把评审发现的全部缺陷修完：

| 文件 | 内容 |
|---|---|
| `src/http-client.ts` | `httpJson` / `httpStream`、`HttpError` / `AuthError`、绝对 deadline、响应体上限、3xx 处置、abort 前置检查、SSE 空行分帧与 UTF-8 边界 |
| `src/queue.ts` | `KeyRotator`、`TranslateQueue`：in-flight 去重、背压保留 P0、round-robin + 每账号在队上限、仅成功触发 `onStable` |
| `src/cache.ts` | `LruSet`、`cacheKey`（含 `context`/`style`，**不含 accountId**）、`CACHE_VERSION=2`、`migrateCacheRows()`、缓存表列白名单 |
| `src/engine.ts` | 两套 body 构建器、`selectRoute` 能力回退、`normalizeContext` 接线、无 Key 抛 `AuthError` 且零出站 |
| `src/runtime.ts` | **可注入依赖** + 真实默认实现（真 md5、真实 `buildContext` / `buildMessages`、内存 settings） |
| `src/crypto-contract.ts` | T10 契约：`safeStorage` 后端白名单（`basic_text` 拒绝启动）、`.bak`/`-wal`/`-shm` 清理、备份排除译文缓存 |
| `test/characterization.test.ts` | 31 条正确行为断言，CI 阻断 |
| `scripts/` + `.github/workflows/` | 基线门禁、构建包装、静态扫描（无 `autoSend`） |

**两个关键设计**

- **依赖可注入**：接真实 Electron / SQLite / 诊断面板时，入口调一次 `configureDeps({...})` 即可，core 不改。
- **安全默认值**：没注入 Key 时 `getToken()` 返回 `null` → 引擎**直接抛 `AuthError`，请求根本不发出**，不会悄悄发 `Bearer null`。

## 看这 3 个文件就够

- **`GAP.md`** — 离「能装上收消息的应用」还差什么（A 我能继续写 / B 需要你提供 / C 必须真机）。**最该先看。**
- **`CHANGES.md`** — PR1→成品的完整变更、矛盾 A 裁决留档、各轮门禁证据。
- **`BASELINE.md`** — PR1 时点的历史数字快照（故意不改，用于对照）。

`test/pending.test.ts` 已清空，只剩关闭记录存档。

## 诚实的边界

这是**核心逻辑成品，不是产品交付**：能跑通全部翻译调度逻辑、不依赖网络和 Key；但**连不上 WhatsApp、收不到消息、写不进输入框、打不出安装包**。差的不是 bug，是 Electron 壳、页面注入、SQLite/safeStorage 接入、API Key 与真机实测——详见 `GAP.md`。

尤其 **§0 七项接口实测没做**，所以 `defaultCaps` 全部为 `false` → 目前一律回退 chat 路径（功能不丢，但术语库路径② 用不了）。

## 与文档的关系

`plan-v1.8.md`、`decision-q1-tos.md` v1.3、`s3-env-baseline.md` **全部保持冻结、未改动**；矛盾 A 的裁决只落在本包 `CHANGES.md`，不回写文档、不再送评审。

仓库里只保留这一个代码包（旧的 PR1/PR2/PR3 包已删除），后续更新覆盖同名文件，**链接不变**。
