// 成品版：关闭 P1-1 / P1-2，保留 §4.2.1 已修好的 SSE 实现。
// 与 httpStream 共用 HttpError / commonHeaders / CA / 结算守卫，不另起一套出站管道。
//
// PR5 新增（非流式）：
//   ✅ P1-1  signal.aborted 前置检查（已取消的请求根本不发）
//   ✅ P1-2  绝对 deadline（心跳推不动）、响应体上限、3xx 显式失败
//   ✅ 结算守卫 + 定时器/监听器解绑（避免长跑累积）

import https from 'node:https';
import type { ClientRequest } from 'node:https';
import { StringDecoder } from 'node:string_decoder';

export class HttpError extends Error {
  constructor(
    public readonly status: number,
    public readonly body: string,
    public readonly retryable: boolean,
  ) { super(`HTTP ${status}: ${body.slice(0, 200)}`); }
  static from(status: number, body: string) {
    return new HttpError(status, body,
      status === 429 || status === 408 || status >= 500);   // 401/403 不重试，直接熔断
  }
}

/** 无 Key 时由引擎抛出，避免发出 "Bearer null"。 */
export class AuthError extends Error {
  constructor(public readonly reason = 'quotaExhausted') {
    super(`NO_API_KEY:${reason}`);
  }
}

export function commonHeaders(h?: Record<string, string>): Record<string, string> {
  return { 'Content-Type': 'application/json', ...h };   // 内部强制，不靠调用方传
}

/** 纯函数：把响应状态与文本转成结果或结构化错误。3xx 显式失败，不自动跟重定向。 */
export function parseJsonResponse(status: number, data: string): { status: number; json: any } {
  if (status >= 300 && status < 400) {
    throw HttpError.from(status, `redirect not followed: ${data.slice(0, 200)}`);
  }
  if (status >= 400) throw HttpError.from(status, data);
  try {
    return { status, json: JSON.parse(data) };
  } catch {
    throw new Error('响应非JSON: ' + data.slice(0, 200));
  }
}

export interface JsonOptions {
  method?: string;
  headers?: Record<string, string>;
  body?: string;
  timeoutMs?: number;          // socket 空闲超时（不是总时长）
  deadlineMs?: number;         // 绝对总时长上限，不受心跳影响
  maxResponseBytes?: number;   // 响应体上限，防 OOM
  ca?: Buffer[];
  signal?: AbortSignal;
}

export async function httpJson(
  url: string,
  options: JsonOptions,
): Promise<{ status: number; json: any }> {
  return new Promise((resolve, reject) => {
    // ✅ P1-1：已取消就不发请求（原实现仍会走 https.request）
    if (options.signal?.aborted) {
      reject(new Error('已取消（请求前）'));
      return;
    }

    const maxBytes = options.maxResponseBytes ?? 2 * 1024 * 1024;
    const deadlineAt = Date.now() + (options.deadlineMs ?? 15_000);
    let deadlineTimer: NodeJS.Timeout | undefined;
    let settled = false;

    const finish = (fn: () => void) => {
      if (settled) return;
      settled = true;
      if (deadlineTimer) clearTimeout(deadlineTimer);
      options.signal?.removeEventListener('abort', onAbort);
      fn();
    };
    const fail = (e: Error) => finish(() => { req?.destroy(); reject(e); });

    // ✅ P1-2：绝对 deadline。每次收到数据后重算剩余，心跳无法把它推后。
    const armDeadline = () => {
      const remaining = Math.max(1, deadlineAt - Date.now());
      if (deadlineTimer) clearTimeout(deadlineTimer);
      deadlineTimer = setTimeout(
        () => fail(new HttpError(408, 'json deadline exceeded', false)), remaining);
    };

    const onAbort = () => fail(new Error('已取消'));
    options.signal?.addEventListener('abort', onAbort, { once: true });
    armDeadline();

    let req!: ClientRequest;
    req = https.request(url, {
      method: options.method ?? 'GET',
      headers: commonHeaders(options.headers),
      ca: options.ca,
      timeout: options.timeoutMs ?? 8_000,
    }, (res) => {
      const status = res.statusCode ?? 0;
      let data = '';
      let bytes = 0;
      res.setEncoding('utf8');
      res.on('data', (c: string) => {
        bytes += Buffer.byteLength(c, 'utf8');
        // ✅ P1-2：响应体上限，超限立即断开，不把整包读进内存
        if (bytes > maxBytes) {
          fail(new HttpError(413, 'response body too large', false));
          return;
        }
        armDeadline();
        data += c;
      });
      res.on('end', () => finish(() => {
        try {
          resolve(parseJsonResponse(status, data));   // ✅ P1-2：3xx / 4xx / 非 JSON 统一处置
        } catch (e) {
          reject(e as Error);
        }
      }));
      res.on('error', fail);
    });
    req.on('timeout', () => fail(new HttpError(408, 'timeout', true)));
    req.on('error', fail);

    if (options.body) req.write(options.body);
    req.end();
  });
}

export type StreamHandlers = {
  onDelta: (text: string) => void;
  onDone: (full: string) => void;
  onError: (e: Error) => void;
};

export interface StreamOptions {
  headers?: Record<string, string>;
  body?: string;
  idleTimeoutMs?: number;
  deadlineMs?: number;
  ca?: Buffer[];
  signal?: AbortSignal;
  requestId: string;
}

/** §4.2.1：StringDecoder + 空行分帧 + [DONE] 主动结算 + 单次结算守卫。 */
export function httpStream(url: string, options: StreamOptions, h: StreamHandlers): void {
  if (options.signal?.aborted) { h.onError(new Error('已取消（请求前）')); return; }

  let req!: ClientRequest;
  const deadlineAt = Date.now() + (options.deadlineMs ?? 15_000);
  let deadlineTimer: NodeJS.Timeout | undefined;

  const onAbort = () => fail(new Error('已取消'));
  const cleanupAbort = () => options.signal?.removeEventListener('abort', onAbort);
  options.signal?.addEventListener('abort', onAbort, { once: true });

  let settled = false;
  const finish = (fn: () => void) => {
    if (settled) return;
    settled = true;
    if (deadlineTimer) clearTimeout(deadlineTimer);
    cleanupAbort();
    fn();
  };
  const fail = (e: Error) => finish(() => { req?.destroy(); h.onError(e); });

  const armDeadline = () => {
    const remaining = Math.max(1, deadlineAt - Date.now());
    if (deadlineTimer) clearTimeout(deadlineTimer);
    deadlineTimer = setTimeout(
      () => fail(new HttpError(408, 'stream deadline exceeded', false)), remaining);
  };

  const decoder = new StringDecoder('utf8');
  let carry = '';
  let eventLines: string[] = [];
  let full = '';

  const dispatchEvent = () => {
    if (!eventLines.length) return;
    const dataParts = eventLines
      .filter(l => l.startsWith('data:'))
      .map(l => l.slice(5).replace(/^ /, ''));
    eventLines = [];
    if (!dataParts.length) return;
    const payload = dataParts.join('\n').trim();
    if (payload === '[DONE]') {
      finish(() => { req.destroy(); h.onDone(full); });
      return;
    }
    try {
      const j = JSON.parse(payload);
      if (j?.error) { fail(new Error(`流式返回错误: ${JSON.stringify(j.error)}`)); return; }
      const d = j.choices?.[0]?.delta?.content ?? j.delta ?? j.text ?? '';
      if (d) { full += d; h.onDelta(d); }
    } catch { /* 注释行 / keep-alive / 非 JSON 心跳，安全跳过 */ }
  };

  const feed = (s: string) => {
    carry += s;
    const lines = carry.split('\n');
    carry = lines.pop() ?? '';
    for (const raw of lines) {
      const line = raw.replace(/\r$/, '');
      if (line === '') { dispatchEvent(); continue; }
      if (line.startsWith(':')) continue;
      eventLines.push(line);
    }
  };

  armDeadline();

  req = https.request(url, {
    method: 'POST',
    headers: { ...commonHeaders(options.headers), Accept: 'text/event-stream' },
    ca: options.ca,
    timeout: options.idleTimeoutMs ?? 5_000,
  }, (res) => {
    if (res.statusCode && res.statusCode >= 300) {
      const errDec = new StringDecoder('utf8');
      let err = '';
      res.on('data', (c: Buffer) => (err += errDec.write(c)));
      res.on('end', () => fail(HttpError.from(res.statusCode!, err)));
      return;
    }
    res.on('data', (chunk: Buffer) => { armDeadline(); feed(decoder.write(chunk)); });
    res.on('end', () => {
      const tail = decoder.end();
      if (tail) feed(tail);
      if (carry.trim()) { eventLines.push(carry); carry = ''; }
      dispatchEvent();
      finish(() => h.onDone(full));
    });
    res.on('error', fail);
  });
  req.on('timeout', () => fail(new HttpError(408, 'idle timeout', true)));
  req.on('error', fail);
  if (options.body) req.write(options.body);
  req.end();
}
