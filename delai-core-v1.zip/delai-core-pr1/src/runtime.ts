// 成品版：把 PR1 的「写死占位」升级为【可注入依赖 + 可用的默认实现】。
// core 因此是自洽、可独立运行的：默认用内存实现即可跑通全部逻辑，
// 接真实 Electron / SQLite / 诊断面板时只需在入口调 configureDeps() 注入，不改 core。
//
// 真实实现已替换的占位：md5（node:crypto）、buildContext（3轮/2000字符）、
// buildMessages（system 术语+风格+背景 / user 原文）、settings（内存 Map）。
// 仍属「外部世界」的只有 caPool / baseUrl / caps / getToken，由装配层提供。

import { createHash } from 'node:crypto';
import type { ContextTurn, TranslateOpts, ApiCaps } from './types';

export interface CoreDiagnostics {
  set(key: string, value: unknown): void;
  inc(key: string, by?: number): void;
}
export interface ViewManager { isActive(accountId: string): boolean }
export interface SettingsStore {
  get(key: string): string | undefined;
  set(key: string, value: string): void;
}
export interface ChatMessage { role: 'system' | 'user' | 'assistant'; content: string }

export interface CoreDeps {
  diagnostics: CoreDiagnostics;
  viewManager: ViewManager;
  settings: SettingsStore;
  glossaryLastUpdated?: (scope: string) => string;
  caPool: Buffer[];
  baseUrl: string;
  caps: ApiCaps;
  /** 返回当前可用的 API Key；全部熔断时必须返回 null（P0-3 由引擎收窄）。
   *  未注入时由组合根 env.ts 的 KeyRotator 提供。 */
  getToken?: () => string | null;
  onQuotaExhausted?: (reason: string) => void;
}

// —— 默认实现（内存版，零外部依赖）——

class MemorySettings implements SettingsStore {
  private m = new Map<string, string>();
  get(key: string) { return this.m.get(key); }
  set(key: string, value: string) { this.m.set(key, value); }
}

export const defaultCaps: ApiCaps = {
  // §0 七项实测前，全部按「不支持」保守取值 → 一律回退 chat（功能不丢）
  openApiEndpointExists: false,
  modelSupportsOpenApi: {
    'hy-mt2-lite': false,
    'hy-mt2-plus': false,
    'hy-mt2-pro': false,
  },
  referencesAcceptTerms: false,
  contextFieldConfirmed: false,
};

let deps: CoreDeps = {
  diagnostics: { set: () => {}, inc: () => {} },
  viewManager: { isActive: () => false },
  settings: new MemorySettings(),
  caPool: [],
  baseUrl: 'https://tokenhub.tencentmaas.com',
  caps: defaultCaps,
};

/** 入口装配：接真实 SQLite / 诊断面板 / KeyRotator 时调用一次。 */
export function configureDeps(next: Partial<CoreDeps>): void {
  deps = { ...deps, ...next };
}
export function getDeps(): CoreDeps { return deps; }

// queue.ts / cache.ts 仍用这两个模块级包装，内部转发到可注入 deps
export const diagnostics: CoreDiagnostics = {
  set: (k, v) => deps.diagnostics.set(k, v),
  inc: (k, n) => deps.diagnostics.inc(k, n),
};
export const viewManager: ViewManager = {
  isActive: (id) => deps.viewManager.isActive(id),
};
export const settings: SettingsStore = {
  get: (k) => deps.settings.get(k),
  set: (k, v) => deps.settings.set(k, v),
};
export const CA_POOL: Buffer[] = deps.caPool;
export const BASE: string = deps.baseUrl;

// —— 真实算法 ——

/** 真 md5（PR1 的 FNV 占位已替换）。跨版本缓存键从此稳定。 */
export function md5(s: string): string {
  return createHash('md5').update(s, 'utf8').digest('hex');
}

export function glossaryLastUpdated(scope: string): string {
  return deps.glossaryLastUpdated?.(scope) ?? '0';
}

/** §12.3 A1：最多 3 轮、总 2000 字符封顶，从最新一轮往前取。 */
export const MAX_CONTEXT_TURNS = 3;
export const MAX_CONTEXT_CHARS = 2000;

export function buildContext(turns?: ContextTurn[]): ContextTurn[] {
  if (!turns?.length) return [];
  const picked: ContextTurn[] = [];
  let chars = 0;
  for (let i = turns.length - 1; i >= 0 && picked.length < MAX_CONTEXT_TURNS; i--) {
    const t = turns[i]!;
    if (chars + t.text.length > MAX_CONTEXT_CHARS) break;
    chars += t.text.length;
    picked.unshift(t);
  }
  return picked;
}

/** §12.5：system = 术语 + 风格 + 背景；user = 原文。路径① prompt 内嵌的真实实现。 */
export function buildMessages(o: TranslateOpts, text: string): ChatMessage[] {
  const sys: string[] = [
    `Translate the user message into ${o.to}. Return only the translation.`,
  ];
  if (o.from) sys.push(`Source language: ${o.from}.`);
  if (o.style) sys.push(`Tone: ${o.style === 'business' ? 'formal business' : 'casual'}.`);

  const terms = o.glossary ?? [];
  if (terms.length) {
    // §4.2.1：命中筛选，最多 20 条、总预算 2k 字符；禁止全量注入
    const picked: string[] = [];
    let budget = MAX_CONTEXT_CHARS;
    for (const t of terms.slice(0, 20)) {
      const line = `"${t.src}" -> "${t.dst}"${t.note ? ` (${t.note})` : ''}`;
      if (budget - line.length < 0) break;
      budget -= line.length;
      picked.push(line);
    }
    if (picked.length) sys.push(`Glossary (use exactly):\n${picked.join('\n')}`);
  }

  const ctx = buildContext(o.contextTurns);
  if (ctx.length) {
    sys.push(`Background conversation:\n${ctx.map(t => `${t.role}: ${t.text}`).join('\n')}`);
  }

  return [
    { role: 'system', content: sys.join('\n\n') },
    { role: 'user', content: text },
  ];
}
