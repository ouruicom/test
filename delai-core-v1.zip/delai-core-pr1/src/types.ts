// 搬迁自 plan-v1.8.md §12.5（2667-2702 行）。仅添加 export，未改任何字段或类型。
// PR2（关闭 P1-3）：补齐 selectRoute() 已引用、但接口漏声明的两个字段。
// 两者均为可选布尔，缺省时行为与 PR1 的 undefined 完全一致（falsy），
// 因此这是「补齐类型声明」，不是改变路由逻辑。

export interface ContextTurn {
  role: 'user' | 'assistant';
  text: string;
}

export interface GlossaryEntry {
  src: string;
  dst: string;
  note?: string;
}

export interface ApiCaps {
  openApiEndpointExists: boolean;
  modelSupportsOpenApi: Record<'hy-mt2-lite' | 'hy-mt2-plus' | 'hy-mt2-pro', boolean>;
  referencesAcceptTerms: boolean;
  glossaryIdLimit?: number;
  contextFieldConfirmed: boolean;
}

export interface TranslateOpts {
  from?: string;
  to: string;
  model?: 'hy-mt2-lite' | 'hy-mt2-plus' | 'hy-mt2-pro';
  // 术语：两条路二选一
  glossary?: GlossaryEntry[];      // 路径①：prompt 内嵌（走 /v1/chat/completions）
  glossaryIds?: string[];          // 路径②：引用持久化术语库（走 /v1/api/translations）
                                   // ⚠️ v1.7.4：官方记为"最多 10 个"，该上限【待实测确认】（§0 第 6 项）。
  contextText?: string;            // 已拼接的上下文全文，直接传给官方 context 字段
  contextTurns?: ContextTurn[];    // 结构化轮次，供 chat 端点 prompt 内嵌【背景信息】
  // ↓ PR2 补齐：§12.5 selectRoute() 第 2713 / 2715 行引用，原接口漏声明（TS2339）
  customerGlossaryHit?: boolean;   // 命中客户级术语 → 若 references 不接受 term，回退 chat
  wantOfficialContext?: boolean;   // 想用官方 context 字段，但该字段未经 §0 第 7 项实测 → 回退 chat
  references?: { type: 'sentence' | 'term'; text: string; translation: string }[];
  style?: 'business' | 'casual';
  stream?: boolean;
  signal?: AbortSignal;
}

export interface TranslatorProvider {
  route(o: TranslateOpts): 'openapi' | 'chat';
  buildBody(o: TranslateOpts, text: string): unknown;
  call(
    o: TranslateOpts,
    text: string,
    ctx: { requestId: string; onDelta?: (s: string) => void },
  ): Promise<unknown>;
}
