// 成品版：关闭 P0-3 / P1-4，并解决 BASELINE.md §4 矛盾 B（两套 body 构建器）。
//
// ✅ P0-3  getToken() 返回 null → 显式抛 AuthError，出站函数【根本不被调用】
//          （模板字符串插值 null 不报错，tsc 抓不到，靠本处类型收窄 + 单测）
// ✅ P1-4  normalizeContext() 真正接线：openapi 用拼接后的 context，chat 用结构化 turns
// ✅ 矛盾B 拆成 buildChatBody / buildOpenApiBody 两个构建器，不再一个函数里加 if
// ✅ 依赖可注入：transport / caps / getToken / 回调全部走构造参数，便于 spy 断言

import type { TranslateOpts, TranslatorProvider, ApiCaps, ContextTurn } from './types';
import { HttpError, AuthError, httpJson as realJson, httpStream as realStream } from './http-client';
import type { StreamHandlers } from './http-client';

export { AuthError, HttpError } from './http-client';
import { getDeps, buildContext, buildMessages } from './runtime';
import {
  defaultGetToken, defaultPenalize, defaultOnThrottle, defaultOnStable,
} from './env';

export type HttpJsonFn = typeof realJson;
export type HttpStreamFn = typeof realStream;

export interface EngineDeps {
  caps?: ApiCaps;
  getToken?: () => string | null;
  json?: HttpJsonFn;
  stream?: HttpStreamFn;
  penalize?: (key: string) => void;
  onThrottle?: () => void;
  onStable?: () => void;
  onQuotaExhausted?: (reason: string) => void;
  baseUrl?: string;
  caPool?: Buffer[];
}

/** 引擎层归一化：两条路线各取所需，调用方只管往上塞 turns。 */
export function normalizeContext(o: TranslateOpts, route: 'openapi' | 'chat') {
  const turns: ContextTurn[] = buildContext(o.contextTurns);   // 3轮/2000字符封顶
  return route === 'openapi'
    ? { text: turns.map(t => `${t.role}: ${t.text}`).join('\n') }  // 角色前缀格式待 §0 第7项实测
    : { turns };
}

export function selectRoute(o: TranslateOpts, caps: ApiCaps): 'openapi' | 'chat' {
  if (!caps.openApiEndpointExists) return 'chat';
  if (!caps.modelSupportsOpenApi[o.model ?? 'hy-mt2-lite']) return 'chat';
  if (!caps.referencesAcceptTerms && o.customerGlossaryHit) return 'chat';
  if ((o.glossaryIds?.length ?? 0) > (caps.glossaryIdLimit ?? 10)) return 'chat';
  if (o.wantOfficialContext && !caps.contextFieldConfirmed) return 'chat';
  return 'openapi';
}

export class HunyuanEngine implements TranslatorProvider {
  private d: EngineDeps;

  constructor(deps: EngineDeps = {}) {
    this.d = deps;
  }

  private get caps(): ApiCaps { return this.d.caps ?? getDeps().caps; }
  private get baseUrl(): string { return this.d.baseUrl ?? getDeps().baseUrl; }
  private get caPool(): Buffer[] { return this.d.caPool ?? getDeps().caPool; }
  private get json(): HttpJsonFn { return this.d.json ?? realJson; }
  private get stream(): HttpStreamFn { return this.d.stream ?? realStream; }
  private getToken(): string | null {
    return this.d.getToken ? this.d.getToken() : (getDeps().getToken ?? defaultGetToken)();
  }

  route(o: TranslateOpts): 'openapi' | 'chat' {
    return selectRoute(o, this.caps);
  }

  // —— 两套独立构建器（矛盾 B 的修复）——

  /** 路径② /v1/api/translations：text + source/target 独立字段 + 官方 context/glossary_ids。 */
  buildOpenApiBody(o: TranslateOpts, text: string): Record<string, unknown> {
    const ctx = normalizeContext(o, 'openapi');
    return {
      model: o.model, text, target: o.to, source: o.from,
      context: ctx.text || o.contextText,   // ✅ P1-4：不再直接塞未处理的 contextText
      glossary_ids: o.glossaryIds,
      references: o.references,
      stream: o.stream ?? false,
    };
  }

  /** 路径① /v1/chat/completions：messages 内嵌术语/风格/背景，user 为原文。 */
  buildChatBody(o: TranslateOpts, text: string): Record<string, unknown> {
    const norm = normalizeContext(o, 'chat');
    return {
      model: o.model,
      stream: o.stream ?? false,
      messages: buildMessages({ ...o, contextTurns: norm.turns }, text),
    };
  }

  buildBody(o: TranslateOpts, text: string): unknown {
    return this.route(o) === 'openapi'
      ? this.buildOpenApiBody(o, text)
      : this.buildChatBody(o, text);
  }

  async call(o: TranslateOpts, text: string, ctx: {
    requestId: string;
    onDelta?: (s: string) => void;
  }): Promise<unknown> {
    // ✅ P0-3：在构造 Authorization 之前收窄。null → 不发请求、直接抛 AuthError。
    const token = this.getToken();
    if (token === null || token === undefined || token === '') {
      const e = new AuthError('quotaExhausted');
      (this.d.onQuotaExhausted ?? getDeps().onQuotaExhausted)?.(e.reason);
      throw e;
    }

    const body = JSON.stringify(this.buildBody(o, text));
    const common = {
      headers: { Authorization: `Bearer ${token}` },
      body, ca: this.caPool, signal: o.signal,
    };
    const url = this.route(o) === 'openapi'
      ? `${this.baseUrl}/v1/api/translations`
      : `${this.baseUrl}/v1/chat/completions`;

    try {
      if (ctx.onDelta) {
        // 流式不自动重试；半截译文由注入层按 requestId 擦除（§4.2.1）
        return await new Promise<string>((res, rej) => {
          const handlers: StreamHandlers = {
            onDelta: ctx.onDelta!,
            onDone: res,
            onError: rej,
          };
          this.stream(url, {
            ...common, requestId: ctx.requestId,
            idleTimeoutMs: 5_000, deadlineMs: 15_000,
          }, handlers);
        });
      }
      const out = await this.json(url, { ...common, timeoutMs: 8_000, deadlineMs: 15_000 });
      (this.d.onStable ?? defaultOnStable)();
      return out.json;
    } catch (e) {
      if (e instanceof HttpError) {
        if (e.status === 401 || e.status === 403) (this.d.penalize ?? defaultPenalize)(token);
        else if (e.retryable) (this.d.onThrottle ?? defaultOnThrottle)();
      }
      throw e;
    }
  }
}
