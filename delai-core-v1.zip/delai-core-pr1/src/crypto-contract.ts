// T10 在 core 层的落地：字段级加密的【契约与安全默认值】。
// 真实 safeStorage / SQLite 属集成层（Electron 主进程），但下面的规则可以在 core 里
// 被完整单测，避免「接上去之后才发现 basic_text 被当成已加密」。

/** T10.1：只允许这些后端；basic_text（Linux 无 keyring 时的明文兜底）视同不可用。 */
export const SECURE_BACKENDS = ['keychain', 'kwallet', 'gnome-libsecret', 'dpapi'] as const;
export type SecureBackend = typeof SECURE_BACKENDS[number];

export class InsecureStorageError extends Error {
  constructor(backend: string) {
    super(`UNSAFE_STORAGE_BACKEND:${backend}`);
  }
}

/**
 * 启动期校验：后端不在白名单 → 抛错，调用方必须【拒绝启动】，
 * 不降级明文、不把 basic_text 当「已加密」蒙混过去。
 */
export function assertSecureBackend(backend: string): SecureBackend {
  if (!(SECURE_BACKENDS as readonly string[]).includes(backend)) {
    throw new InsecureStorageError(backend);
  }
  return backend as SecureBackend;
}

/** Q3 字段级加密口径：与 decision-q1-tos.md §6.2 一致，供 schema 生成时核对。 */
export const ENCRYPTED_FIELDS = [
  'customers.note', 'customers.tags',
  'glossary.src', 'glossary.dst', 'glossary.note',
  'templates.body',
  'conversations.last_msg_preview',
] as const;

export const PLAINTEXT_FIELDS = [
  'translation_cache.dst_text',   // 量大、高频读写、是译文非原文；但必须禁存 src_text
  'usage_stats.*', 'schema_meta.*',
] as const;

/** T10.2：WAL 模式下备份/清理必须覆盖的三种文件后缀。 */
export const CLEANUP_SUFFIXES = ['.bak', '-wal', '-shm'] as const;

/** 备份时排除的表：译文缓存不进 .bak，避免明文副本长期留在 %APPDATA%。 */
export const BACKUP_EXCLUDED_TABLES = ['translation_cache'] as const;

/** 给备份文件名用：返回所有需要清理的派生文件名。 */
export function derivedFiles(dbPath: string): string[] {
  return CLEANUP_SUFFIXES.map(s => dbPath + s);
}

/** 缓存表准入校验：出现 src_text / last_msg_preview 这类原文列直接拒绝建表。 */
export function assertCacheSchema(columns: readonly string[]): void {
  const forbidden = ['src_text', 'last_msg_preview', 'raw_text', 'src'];
  const hit = columns.find(c => forbidden.includes(c));
  if (hit) throw new Error(`CACHE_SCHEMA_FORBIDDEN_COLUMN:${hit}`);
}
