// 组合根：把 runtime 的可注入 deps 与队列 / Key 轮换装配起来。
// 成品版不再是「空数组 → 恒返回 null」的占位：默认给出可工作的实现，
// 真实 Key 由 configureDeps({ getToken }) 注入；没注入时返回 null → 引擎抛 AuthError（P0-3 正确路径）。

import { KeyRotator, TranslateQueue } from './queue';
import { getDeps } from './runtime';

export const translateQueue = new TranslateQueue();

let rotator = new KeyRotator([]);
let lastKeys: string[] = [];

/** Key 列表变化时才重建，保证 cooldown 在多次调用之间持久。 */
export function currentKeyRotator(): KeyRotator {
  const keys = (getDeps() as unknown as { keys?: string[] }).keys ?? [];
  if (keys.length !== lastKeys.length || keys.some((k, i) => k !== lastKeys[i])) {
    rotator = new KeyRotator(keys);
    lastKeys = [...keys];
  }
  return rotator;
}

export function defaultGetToken(): string | null { return currentKeyRotator().next(); }
export function defaultPenalize(key: string): void { currentKeyRotator().penalize(key); }
export function defaultOnThrottle(): void { translateQueue.onThrottle(); }
export function defaultOnStable(): void { translateQueue.onStable(); }
