// 搬迁自 plan-v1.8.md §4.4（985-1089 行）。仅补 export / import，逐行照搬。
//
// PR3 关闭 4 条队列层缺陷（本 PR 只动 queue.ts 这一层）：
//   ✅ P0-1  applyBackpressure 比较符写反（降序 → 切掉的是 P0）
//   ✅ P0-4  onStable() 零调用点（并发只降不升）
//   ✅ PR1 运行时新发现① 同 key 去重不覆盖 in-flight
//   ✅ T9.5  全局 FIFO 无按账号轮转 / 无每账号在队上限
//
// ⚠️ 仍保留（不在本 PR 范围）：
//   队列本体仍全局单例（正确：maxConcurrent 由 §0 实测 API QPS 决定，见 §5 修正 2）；
//   P0-2 / v1.3 cacheKey 属 PR4；P0-3 / P1-1 / P1-2 / P1-4 属 PR5–PR6。

import { diagnostics, viewManager } from './runtime';

export class KeyRotator {
  private idx = 0;
  private cooldown = new Map<string, number>();

  constructor(private keys: string[]) {}

  next(): string | null {
    const now = Date.now();
    const avail = this.keys.filter(k => (this.cooldown.get(k) ?? 0) <= now);
    if (!avail.length) return null;                 // 全部熔断
    const k = avail[this.idx % avail.length];
    this.idx++;
    // PR2：strict + noUncheckedIndexedAccess 下数组下标访问可能是 undefined。
    // 取模保证下标在范围内，`?? null` 是类型兜底，不改变任何运行行为。
    return k ?? null;
  }

  penalize(key: string, ms = 60_000) {              // 401/403/连续失败
    this.cooldown.set(key, Date.now() + ms);
  }
}

export type Priority = 0 | 1 | 2;   // 0=当前可见会话 1=同账号其它会话 2=后台账号

export interface Job {
  key: string;                // 文本去重键（同文本合并，不重复请求）
  priority: Priority;
  accountId: string;
  run: () => Promise<void>;
  enqueuedAt: number;
}

export class TranslateQueue {
  private queue: Job[] = [];
  private active = 0;
  private maxConcurrent: number;
  private readonly min: number;
  private readonly ceiling: number;
  private stableSince = Date.now();

  private readonly MAX_QUEUE = 200;       // 背压上限
  private readonly MAX_AGE_MS = 30_000;   // 排队超 30s 的旧任务直接作废

  // PR3：in-flight 键集合 + 每账号在队上限 + round-robin 游标
  private readonly inflight = new Set<string>();
  private lastAccount: string | null = null;
  private readonly perAccountCap: number;

  constructor(initial = 4, min = 1, ceiling = 8, perAccountCap = 25) {
    this.maxConcurrent = initial;
    this.min = min;
    this.ceiling = ceiling;   // 上限以 §0 第 4 项实测为准，不写死 5
    this.perAccountCap = perAccountCap;
  }

  // 收到 429 / 连续超时 → 立即砍半，并记录不稳定
  onThrottle() {
    this.maxConcurrent = Math.max(this.min, Math.floor(this.maxConcurrent / 2));
    this.stableSince = Date.now();
    diagnostics.set('translate.concurrency', this.maxConcurrent);
  }

  // 稳定成功一段时间（建议 60s）→ 缓慢回升 +1，避免刚恢复又撞限流
  onStable() {
    if (Date.now() - this.stableSince < 60_000) return;
    this.maxConcurrent = Math.min(this.ceiling, this.maxConcurrent + 1);
    this.stableSince = Date.now();
    diagnostics.set('translate.concurrency', this.maxConcurrent);
  }

  push(job: Job) {
    // PR3：判重覆盖【队列残留 + 正在执行】，否则 pump 把 job shift 出去后
    // 第二条同 key 会漏过检查（PR1 实测推 5 条全执行）。
    if (this.inflight.has(job.key) || this.queue.some(j => j.key === job.key)) return;

    // PR3 / T9.5：每账号在队上限，防止 1 号灌满全局队列饿死其它账号。
    // 只统计「排队中」，不含 inflight（inflight 已受 maxConcurrent 全局约束）。
    const inQueue = this.queue.reduce(
      (n, j) => n + (j.accountId === job.accountId ? 1 : 0), 0);
    if (inQueue >= this.perAccountCap) {
      diagnostics.inc('translate.dropped.perAccountCap');
      return;
    }

    this.queue.push(job);
    this.applyBackpressure();
    this.pump();
  }

  private applyBackpressure() {
    this.queue = this.queue.filter(j => {
      if (Date.now() - j.enqueuedAt < this.MAX_AGE_MS) return true;
      diagnostics.inc('translate.dropped.stale');
      return false;
    });
    if (this.queue.length <= this.MAX_QUEUE) return;
    // PR3 / P0-1：排序含义是【谁该被保留在前 200】。
    //  P0 最该保留 → priority 升序；
    //  同优先级里旧任务更该丢 → enqueuedAt 降序（新的排前面）。
    // 原文 `b.priority - a.priority` 是降序，把 P2 放前面保留、P0 放尾部被切，
    // 与注释「当前可见会话绝不丢」完全相反。
    this.queue.sort((a, b) => a.priority - b.priority || b.enqueuedAt - a.enqueuedAt);
    const dropped = this.queue.splice(this.MAX_QUEUE);
    diagnostics.inc('translate.dropped.backpressure', dropped.length);
  }

  // PR3 / T9.5：跨账号 round-robin 选下一个账号，账号内仍按优先级 + FIFO。
  // 注意与 applyBackpressure 的排序目的不同（那边是「谁该保留」，这边是「谁先出队」）。
  private pickNext(): number {
    const accounts: string[] = [];
    for (const j of this.queue) {
      if (!accounts.includes(j.accountId)) accounts.push(j.accountId);
    }
    if (!accounts.length) return -1;

    let start = 0;
    if (this.lastAccount) {
      const i = accounts.indexOf(this.lastAccount);
      if (i >= 0) start = (i + 1) % accounts.length;
    }
    for (let n = 0; n < accounts.length; n++) {
      const acc = accounts[(start + n) % accounts.length]!;
      let best = -1;
      for (let i = 0; i < this.queue.length; i++) {
        const j = this.queue[i]!;
        if (j.accountId !== acc) continue;
        if (best < 0) { best = i; continue; }
        const cur = this.queue[best]!;
        if (j.priority < cur.priority ||
            (j.priority === cur.priority && j.enqueuedAt < cur.enqueuedAt)) best = i;
      }
      if (best >= 0) return best;
    }
    return -1;
  }

  private pump() {
    while (this.active < this.maxConcurrent && this.queue.length) {
      const idx = this.pickNext();
      if (idx < 0) break;
      const job = this.queue.splice(idx, 1)[0]!;
      this.active++;
      this.inflight.add(job.key);
      this.lastAccount = job.accountId;

      // PR3 / P0-4：仅【成功】计入稳定 → onStable 才可能回升并发。
      // 失败不计稳定（节流由引擎侧 onThrottle 处理）；两参 then 顺手接住 rejection，
      // 避免原实现 `run().finally()` 在 run 抛错时产生 unhandled rejection。
      job.run()
        .then(() => this.onStable(), () => { /* 失败不计入稳定 */ })
        .finally(() => {
          this.active--;
          this.inflight.delete(job.key);
          this.pump();
        });
    }
  }
}

// 优先级判定：主进程知道哪个 accountId 当前 visible
export function priorityOf(accountId: string, isCurrentConversation: boolean): Priority {
  if (isCurrentConversation) return 0;
  return viewManager.isActive(accountId) ? 1 : 2;
}
