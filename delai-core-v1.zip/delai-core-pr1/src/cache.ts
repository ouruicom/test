// 成品版：关闭 P0-2、落档矛盾 A 裁决、实现 T9.6 迁移机制。
//
// 【2026-11-03 用户裁决 — 矛盾 A】
//   **不补 accountId**。`scope=global` 的译文跨账号共享是设计意图（plan-v1.8 §4.4）。
//   理由：补键会废掉 R18「高频话术秒回」；客户级术语已由 glossaryScopeKey 隔离；
//   真正的「串味」是漏 context/style（本文件已修）；真正的隐私面在落盘，
//   由「缓存表禁存 src_text 明文」+ T10.2 备份清理处置，与 key 无关。
//   本结论偏离 decision-q1-tos.md v1.2/v1.3 的表述，见 CHANGES.md。

import { md5, settings, glossaryLastUpdated, buildContext } from './runtime';
import type { ContextTurn } from './types';

export class LruSet {
  constructor(private max = 3000) {}
  private map = new Map<string, true>();
  has(k: string) {
    if (!this.map.has(k)) return false;
    this.map.delete(k); this.map.set(k, true);   // 命中也提序（v1.7.3）
    return true;
  }
  add(k: string) {
    this.map.delete(k); this.map.set(k, true);
    if (this.map.size > this.max) {
      this.map.delete(this.map.keys().next().value!);
    }
  }
}

export function globalGlossaryVersion(): string {
  const v = settings.get('glossary_version_global');
  return /^\d+$/.test(v ?? '') ? v! : '1';    // 缺失或非法 → 回落 '1'
}

/** 递增全局术语表版本号（必须用 UPSERT；原 v1.5.2 的裸 UPDATE 在 key 缺失时影响 0 行）。 */
export function bumpGlobalGlossaryVersion(): string {
  const cur = Number(globalGlossaryVersion());
  const next = String(Number.isFinite(cur) ? cur + 1 : 2);
  settings.set('glossary_version_global', next);
  return next;
}

export function glossaryScopeKey(scope: string): string {
  if (scope === 'global') return `g${globalGlossaryVersion()}`;
  return `c${scope}:${glossaryLastUpdated(scope)}`;   // 客户级独立版本
}

// —— 缓存键版本（T9.6）——
// v2：补 context / style。任何一次键形状变更都必须 +1，否则旧译文会被错误命中。
// 注意：不补 accountId 是裁决结果；但 v1→v2 仍会触发全量旧缓存失效，迁移机制照做。
export const CACHE_VERSION = 2;

/** 上下文摘要：只用进键的「形状」，不存原文，避免缓存表落 src_text 明文。 */
function contextDigest(contextText?: string, contextTurns?: ContextTurn[]): string {
  const parts: string[] = [];
  if (contextText) parts.push(`t:${contextText}`);
  const turns = buildContext(contextTurns);
  if (turns.length) parts.push(`r:${turns.map(t => `${t.role[0]}${t.text}`).join('|')}`);
  return parts.length ? md5(parts.join('\n')).slice(0, 12) : '-';
}

export interface CacheKeyParams {
  engine: string;
  model: string;
  from: string;
  to: string;
  text: string;
  scope: string;
  // PR4 新增（P0-2）：上下文与风格参与键，避免「please confirm」在不同语境串味
  contextText?: string;
  contextTurns?: ContextTurn[];
  style?: 'business' | 'casual';
}

export function cacheKey(p: CacheKeyParams): string {
  const ctx = contextDigest(p.contextText, p.contextTurns);
  const style = p.style ?? '-';
  const raw = `v${CACHE_VERSION}|${p.engine}|${p.model}|${p.from}|${p.to}|` +
              `${glossaryScopeKey(p.scope)}|${ctx}|${style}|${p.text}`;
  return md5(raw);
}

/** 供缓存表 DDL 使用：只允许这些列，明确禁止 src_text / last_msg_preview 明文列。 */
export const ALLOWED_CACHE_COLUMNS = [
  'key_hash', 'dst_text', 'engine', 'model', 'hit_count', 'cache_version', 'created_at',
] as const;

export interface CacheRow { key_hash: string; cache_version: number }

/**
 * T9.6 迁移：返回需要删除的旧条目与保留的条目。
 * 纯函数、可单测；真实 SQLite 接入时按 purge 列表 DELETE + 预热 Top N 即可。
 * 推荐「键 + 版本号」而非按账号分库（后者与 §4.7.1 单连接 + WAL 约束冲突）。
 */
export function migrateCacheRows(rows: CacheRow[]): {
  purge: CacheRow[];
  keep: CacheRow[];
  needsRewarm: boolean;
} {
  const purge = rows.filter(r => r.cache_version < CACHE_VERSION);
  const keep = rows.filter(r => r.cache_version >= CACHE_VERSION);
  return { purge, keep, needsRewarm: purge.length > 0 };
}
