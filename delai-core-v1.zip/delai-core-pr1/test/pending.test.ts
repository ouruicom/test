// ✅ 全部缺陷已关闭（成品版）。本文件保留为「关闭记录」存档，不再含 todo 用例。
//
// PR2 关闭：P1-3（TranslateOpts 补两字段）、P1-5（buildMessages 接入）、
//           TS2554（penalize 补参）、TS2322（?? null）、PR1 运行时新发现②。
// PR3 关闭：P0-1（背压比较符）、P0-4（onStable 接线）、T9.5（round-robin + perAccountCap）、
//           PR1 运行时新发现①（in-flight 去重）。
// 裁决移除：v1.3「cacheKey 不含 accountId」——用户裁定不补，global 跨账号共享是设计意图
//           （见 CHANGES.md 矛盾 A）。
// 成品版关闭：
//   P0-2  cacheKey 补 context / style（contextDigest 只进哈希，不落原文）
//   P0-3  getToken() 收窄 → 抛 AuthError，出站函数零调用
//   P1-1  signal.aborted 前置检查
//   P1-2  绝对 deadline / 响应体上限 / 3xx 显式失败（parseJsonResponse 可单测）
//   P1-4  normalizeContext 接线（buildOpenApiBody 用拼接后的 context）
//   矛盾B  拆成 buildChatBody / buildOpenApiBody 两个独立构建器
//   T9.6  CACHE_VERSION=2 + migrateCacheRows() 纯函数迁移与重新预热
//   T1    静态扫描进 CI（.github/workflows/core.yml，无 autoSend/autoSubmit 入口）
//   T10.1 assertSecureBackend 白名单（basic_text 拒绝启动）
//   T10.2 derivedFiles 覆盖 .bak/-wal/-shm + 备份排除译文缓存
//
// 仍不属于「代码缺陷」、走发布检查单 / 集成层的事项见 GAP.md：
//   §0 七项真实请求、三层写入实测、24h 长稳、真实 safeStorage/SQLite 接入、Electron 壳。
//
// 正确行为断言全部在 test/characterization.test.ts（CI 阻断）。

export {};
