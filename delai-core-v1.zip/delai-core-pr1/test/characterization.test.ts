// 成品版验收：CI 阻断。全部为【正确行为】断言，不再有「现状固化」的缺陷记录用例。
// 对应 §8.1 单测/集成层；真机 / 长稳（74 / 79 / 85）仍走发布检查单，不进 CI。

import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  HttpError, AuthError, commonHeaders, parseJsonResponse, httpJson,
} from '../src/http-client';
import type { HttpJsonFn, HttpStreamFn } from '../src/engine';
import {
  LruSet, cacheKey, globalGlossaryVersion, bumpGlobalGlossaryVersion,
  glossaryScopeKey, migrateCacheRows, CACHE_VERSION, ALLOWED_CACHE_COLUMNS,
} from '../src/cache';
import { KeyRotator, TranslateQueue, priorityOf } from '../src/queue';
import type { Job, Priority } from '../src/queue';
import { selectRoute, normalizeContext, HunyuanEngine } from '../src/engine';
import {
  defaultCaps, md5, buildContext, buildMessages, configureDeps, getDeps,
} from '../src/runtime';
import {
  assertSecureBackend, InsecureStorageError, derivedFiles, assertCacheSchema,
  SECURE_BACKENDS, BACKUP_EXCLUDED_TABLES,
} from '../src/crypto-contract';
import type { TranslateOpts, ApiCaps } from '../src/types';

const capsAll: ApiCaps = {
  openApiEndpointExists: true,
  modelSupportsOpenApi: { 'hy-mt2-lite': true, 'hy-mt2-plus': true, 'hy-mt2-pro': true },
  referencesAcceptTerms: true,
  glossaryIdLimit: 10,
  contextFieldConfirmed: true,
};

// ——— HTTP 层 ———

test('HttpError.from：429/408/5xx 可重试，401/403/400 不重试', () => {
  assert.equal(HttpError.from(429, '').retryable, true);
  assert.equal(HttpError.from(408, '').retryable, true);
  assert.equal(HttpError.from(503, '').retryable, true);
  assert.equal(HttpError.from(401, '').retryable, false);
  assert.equal(HttpError.from(403, '').retryable, false);
  assert.equal(HttpError.from(400, '').retryable, false);
});

test('commonHeaders：强制 Content-Type', () => {
  assert.deepEqual(commonHeaders(), { 'Content-Type': 'application/json' });
  assert.deepEqual(commonHeaders({ Authorization: 'Bearer k' }), {
    'Content-Type': 'application/json', Authorization: 'Bearer k',
  });
});

test('P1-2：parseJsonResponse 对 3xx 显式失败、4xx 结构化错误、非 JSON 报错', () => {
  assert.throws(() => parseJsonResponse(302, 'moved'), /redirect not followed/);
  assert.throws(() => parseJsonResponse(429, 'slow down'), (e: unknown) =>
    e instanceof HttpError && e.status === 429 && e.retryable);
  assert.throws(() => parseJsonResponse(200, '<html>'), /响应非JSON/);
  assert.deepEqual(parseJsonResponse(200, '{"ok":1}'), { status: 200, json: { ok: 1 } });
});

test('P1-1：已 abort 的 signal 不发请求，直接拒绝（无网络调用）', async () => {
  const ac = new AbortController();
  ac.abort();
  await assert.rejects(
    httpJson('https://example.invalid/x', { signal: ac.signal }),
    /已取消（请求前）/,
  );
});

// ——— 缓存层 ———

test('md5 是真实 32 位十六进制（PR1 的 FNV 占位已替换）', () => {
  const h = md5('MOQ?');
  assert.match(h, /^[0-9a-f]{32}$/);
  assert.equal(md5('MOQ?'), h);
  assert.notEqual(md5('shipping cost?'), h);
});

test('LruSet：读命中提升新鲜度', () => {
  const s = new LruSet(2);
  s.add('a'); s.add('b'); s.has('a'); s.add('c');
  assert.equal(s.has('a'), true);
  assert.equal(s.has('b'), false);
  assert.equal(s.has('c'), true);
});

test('术语表版本号：缺失回落 1，bump 后真递增（v1.5.2 的裸 UPDATE 已修）', () => {
  const store = { get: (_k: string) => undefined as string | undefined,
                  set: (_k: string, _v: string) => {} };
  let v: string | undefined;
  store.get = (k) => (k === 'glossary_version_global' ? v : undefined);
  store.set = (k, val) => { if (k === 'glossary_version_global') v = val; };
  configureDeps({ settings: store });
  assert.equal(globalGlossaryVersion(), '1');
  assert.equal(bumpGlobalGlossaryVersion(), '2');
  assert.equal(globalGlossaryVersion(), '2');
  assert.equal(bumpGlobalGlossaryVersion(), '3');
});

test('glossaryScopeKey：global 与 customer 各自独立版本', () => {
  configureDeps({ glossaryLastUpdated: (s) => s === 'customer:alice' ? '111' : '222' });
  assert.match(glossaryScopeKey('global'), /^g\d+$/);
  assert.equal(glossaryScopeKey('customer:alice'), 'ccustomer:alice:111');
  assert.equal(glossaryScopeKey('customer:bob'), 'ccustomer:bob:222');
});

test('P0-2：cacheKey 补 context / style，同句不同语境/风格不再串味', () => {
  const base = { engine: 'hunyuan', model: 'hy-mt2-lite', from: 'en', to: 'zh',
                 text: 'please confirm', scope: 'global' };
  assert.equal(cacheKey(base), cacheKey({ ...base }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, style: 'business' }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, contextText: '催发货' }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base,
    contextTurns: [{ role: 'user', text: 'quotation?' }] }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, model: 'hy-mt2-pro' }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, text: 'MOQ?' }));
});

test('矛盾 A 裁决：global 译文跨账号共享（key 不含 accountId）', () => {
  const p = { engine: 'hunyuan', model: 'hy-mt2-lite', from: 'en', to: 'zh',
              text: 'MOQ?', scope: 'global' };
  // 调用方没有 accountId 参数 —— 这是设计意图，不是漏网（CHANGES.md 裁决留档）
  assert.equal(cacheKey(p), cacheKey({ ...p }));
  // 客户级 scope 互不相同
  assert.notEqual(cacheKey({ ...p, scope: 'customer:alice' }),
                  cacheKey({ ...p, scope: 'customer:bob' }));
});

test('T9.6：cache_version 迁移能识别并清除旧版本条目、触发重新预热', () => {
  assert.equal(CACHE_VERSION, 2);
  const rows = [
    { key_hash: 'a', cache_version: 1 },
    { key_hash: 'b', cache_version: 2 },
    { key_hash: 'c', cache_version: 1 },
  ];
  const r = migrateCacheRows(rows);
  assert.equal(r.purge.length, 2);
  assert.equal(r.keep.length, 1);
  assert.equal(r.needsRewarm, true);
  assert.equal(migrateCacheRows([{ key_hash: 'b', cache_version: 2 }]).needsRewarm, false);
});

test('隐私硬约束：缓存表列白名单不含 src_text / last_msg_preview', () => {
  assert.ok(!ALLOWED_CACHE_COLUMNS.includes('src_text' as never));
  assert.ok(!ALLOWED_CACHE_COLUMNS.includes('last_msg_preview' as never));
  assert.throws(() => assertCacheSchema(['key_hash', 'src_text']), /FORBIDDEN_COLUMN:src_text/);
  assert.throws(() => assertCacheSchema(['key_hash', 'last_msg_preview']), /FORBIDDEN_COLUMN/);
  assertCacheSchema(ALLOWED_CACHE_COLUMNS);
});

// ——— 队列层（PR3 成果回归）———

test('KeyRotator：无可用 Key 返回 null；penalize 后进入冷却', () => {
  assert.equal(new KeyRotator([]).next(), null);
  const r = new KeyRotator(['k1', 'k2']);
  assert.equal(r.next(), 'k1');
  r.penalize('k1');
  assert.equal(r.next(), 'k2');
  r.penalize('k2');
  assert.equal(r.next(), null);
});

test('priorityOf：当前会话 P0；其余由 viewManager 决定', () => {
  assert.equal(priorityOf('a1', true), 0);
  assert.equal(priorityOf('a1', false), 2);
});

test('in-flight 去重：同 key 只执行一次，并发不超上限', async () => {
  const q = new TranslateQueue(2, 1, 8);
  let peak = 0, running = 0, calls = 0;
  const make = (key: string): Job => ({ key, priority: 0, accountId: 'a1',
    enqueuedAt: Date.now(), run: async () => {
      calls++; running++; peak = Math.max(peak, running);
      await new Promise<void>(r => setTimeout(r, 5)); running--;
    } });
  q.push(make('x')); q.push(make('x'));
  q.push(make('y')); q.push(make('z')); q.push(make('w'));
  await new Promise<void>(r => setTimeout(r, 60));
  assert.equal(calls, 4);
  assert.ok(peak <= 2);
});

test('P0-1：背压超限时 50 条 P0 一条不丢', async () => {
  let release!: () => void;
  const gate = new Promise<void>(r => { release = r; });
  const q = new TranslateQueue(1, 1, 8, 1000);
  const order: Priority[] = [];
  const make = (key: string, priority: Priority): Job => ({ key, priority,
    accountId: 'a1', enqueuedAt: Date.now() + Number(key.slice(1)),
    run: async () => { order.push(priority); await gate; } });
  q.push(make('k0', 2));
  for (let i = 1; i <= 50; i++) q.push(make(`k${i}`, 0));
  for (let i = 51; i <= 210; i++) q.push(make(`k${i}`, 2));
  release();
  await new Promise<void>(r => setTimeout(r, 120));
  assert.equal(order.filter(p => p === 0).length, 50);
  assert.ok(order.length < 211);
});

test('P0-4：仅成功任务触发 onStable', async () => {
  const q = new TranslateQueue(2, 1, 8, 1000);
  let n = 0;
  (q as unknown as { onStable: () => void }).onStable = () => { n++; };
  const mk = (key: string, fail: boolean): Job => ({ key, priority: 0,
    accountId: 'a1', enqueuedAt: Date.now(),
    run: async () => { if (fail) throw new Error('500'); await Promise.resolve(); } });
  q.push(mk('a', false)); q.push(mk('b', false)); q.push(mk('c', true));
  await new Promise<void>(r => setTimeout(r, 40));
  assert.equal(n, 2);
});

test('T9.5：round-robin 让 1 号堆积时 8 号第二个出队', async () => {
  let release!: () => void;
  const gate = new Promise<void>(r => { release = r; });
  const q = new TranslateQueue(1, 1, 8);
  const order: string[] = [];
  const mk = (key: string, accountId: string): Job => ({ key, priority: 0,
    accountId, enqueuedAt: Date.now(),
    run: async () => { order.push(accountId); await gate; } });
  q.push(mk('k0', 'a1'));
  for (let i = 1; i <= 20; i++) q.push(mk(`k${i}`, 'a1'));
  q.push(mk('p0', 'a8'));
  release();
  await new Promise<void>(r => setTimeout(r, 100));
  assert.equal(order[0], 'a1');
  assert.equal(order[1], 'a8');
});

test('T9.5：perAccountCap 生效，单账号灌不满全局队列', async () => {
  let release!: () => void;
  const gate = new Promise<void>(r => { release = r; });
  const q = new TranslateQueue(1, 1, 8, 3);
  const order: string[] = [];
  const mk = (key: string): Job => ({ key, priority: 0, accountId: 'a1',
    enqueuedAt: Date.now(), run: async () => { order.push(key); await gate; } });
  q.push(mk('k0'));
  for (let i = 1; i <= 8; i++) q.push(mk(`k${i}`));
  release();
  await new Promise<void>(r => setTimeout(r, 60));
  assert.equal(order.length, 4);
});

// ——— 引擎层（PR4/PR5/PR6 成果）———

test('selectRoute：§0 未实测前一律回退 chat；能力齐备且带两个新字段时正确判定', () => {
  assert.equal(selectRoute({ to: 'zh' }, defaultCaps), 'chat');
  assert.equal(selectRoute({ to: 'zh' }, capsAll), 'openapi');
  assert.equal(selectRoute({ to: 'zh', customerGlossaryHit: true },
    { ...capsAll, referencesAcceptTerms: false }), 'chat');
  assert.equal(selectRoute({ to: 'zh', wantOfficialContext: true },
    { ...capsAll, contextFieldConfirmed: false }), 'chat');
  assert.equal(selectRoute({ to: 'zh', glossaryIds: Array(11).fill('g') }, capsAll), 'chat');
});

test('buildContext：3 轮 / 2000 字符封顶，从最新往前取', () => {
  const turns = Array.from({ length: 6 }, (_, i) =>
    ({ role: 'user' as const, text: `t${i}` }));
  const r = buildContext(turns);
  assert.equal(r.length, 3);
  assert.deepEqual(r.map(t => t.text), ['t3', 't4', 't5']);
  assert.equal(buildContext([{ role: 'user', text: 'x'.repeat(2100) }]).length, 0);
});

test('buildMessages 真实实现：system 含术语/风格/背景，user 为原文', () => {
  const o: TranslateOpts = {
    to: 'zh', from: 'en', style: 'business',
    glossary: [{ src: 'LED', dst: 'LED灯' }],
    contextTurns: [{ role: 'user', text: 'MOQ?' }],
  };
  const m = buildMessages(o, 'please confirm');
  assert.equal(m.length, 2);
  assert.equal(m[0]!.role, 'system');
  assert.match(m[0]!.content, /LED.*LED灯/);
  assert.match(m[0]!.content, /formal business/);
  assert.match(m[0]!.content, /MOQ\?/);
  assert.equal(m[1]!.content, 'please confirm');
});

test('矛盾 B：buildChatBody / buildOpenApiBody 两套独立构建器', () => {
  const e = new HunyuanEngine({ caps: defaultCaps });
  const chat = e.buildChatBody({ to: 'zh' }, 'hi') as any;
  const open = e.buildOpenApiBody({ to: 'zh' }, 'hi') as any;
  assert.ok(Array.isArray(chat.messages));
  assert.equal(chat.text, undefined);
  assert.equal(open.text, 'hi');
  assert.equal(open.target, 'zh');
  assert.equal(open.messages, undefined);
});

test('P1-4：normalizeContext 已接线 —— openapi body 的 context 来自结构化轮次', () => {
  const e = new HunyuanEngine({ caps: capsAll });
  const body = e.buildOpenApiBody({ to: 'zh',
    contextTurns: [{ role: 'user', text: 'MOQ?' }, { role: 'assistant', text: '500 pcs' }] },
    'and shipping?') as any;
  assert.equal(body.context, 'user: MOQ?\nassistant: 500 pcs');
  assert.deepEqual(normalizeContext({ to: 'zh' }, 'chat'), { turns: [] });
});

test('P0-3：无 Key 抛 AuthError，且出站函数【根本不被调用】', async () => {
  let jsonCalls = 0, streamCalls = 0;
  const json = (async () => { jsonCalls++; return { status: 200, json: {} }; }) as unknown as HttpJsonFn;
  const stream = (() => { streamCalls++; }) as unknown as HttpStreamFn;
  const e = new HunyuanEngine({ getToken: () => null, json, stream, caps: defaultCaps });
  await assert.rejects(
    e.call({ to: 'zh' }, 'hi', { requestId: 'r1' }),
    (err: unknown) => err instanceof AuthError && err.reason === 'quotaExhausted',
  );
  assert.equal(jsonCalls, 0);
  assert.equal(streamCalls, 0);
});

test('成功路径：有 Key 时正常走 json transport，并回调 onStable', async () => {
  let seenUrl = '', seenAuth = '';
  const json = (async (url: string, opts: any) => {
    seenUrl = url; seenAuth = opts.headers.Authorization;
    return { status: 200, json: { translation: '请确认' } };
  }) as unknown as HttpJsonFn;
  let stable = 0;
  const e = new HunyuanEngine({ getToken: () => 'k1', json,
    caps: defaultCaps, onStable: () => { stable++; } });
  const out = await e.call({ to: 'zh' }, 'please confirm', { requestId: 'r2' }) as any;
  assert.equal(out.translation, '请确认');
  assert.equal(seenAuth, 'Bearer k1');
  assert.match(seenUrl, /\/v1\/chat\/completions$/);
  assert.equal(stable, 1);
});

test('401 走 penalize 不重试；429 走 onThrottle', async () => {
  let penalized = '', throttled = 0;
  const mkJson = (status: number) => (async () => {
    throw HttpError.from(status, 'x');
  }) as unknown as HttpJsonFn;
  const base = { getToken: () => 'k1' as string | null, caps: defaultCaps,
    penalize: (k: string) => { penalized = k; }, onThrottle: () => { throttled++; } };
  await assert.rejects(new HunyuanEngine({ ...base, json: mkJson(401) })
    .call({ to: 'zh' }, 'x', { requestId: 'r3' }));
  assert.equal(penalized, 'k1');
  assert.equal(throttled, 0);
  await assert.rejects(new HunyuanEngine({ ...base, json: mkJson(429) })
    .call({ to: 'zh' }, 'x', { requestId: 'r4' }));
  assert.equal(throttled, 1);
});

// ——— T10 契约层 ———

test('T10.1：basic_text 视同不可用，拒绝启动不降级明文', () => {
  for (const b of SECURE_BACKENDS) assert.equal(assertSecureBackend(b), b);
  assert.throws(() => assertSecureBackend('basic_text'),
    (e: unknown) => e instanceof InsecureStorageError);
  assert.throws(() => assertSecureBackend('unknown'), /UNSAFE_STORAGE_BACKEND/);
});

test('T10.2：清理覆盖 .bak / -wal / -shm，备份排除译文缓存', () => {
  const files = derivedFiles('delai.db');
  assert.deepEqual(files, ['delai.db.bak', 'delai.db-wal', 'delai.db-shm']);
  assert.ok(BACKUP_EXCLUDED_TABLES.includes('translation_cache'));
});

test('组合根可注入：configureDeps 后 getDeps 反映新配置', () => {
  configureDeps({ baseUrl: 'https://example.test' });
  assert.equal(getDeps().baseUrl, 'https://example.test');
  configureDeps({ baseUrl: 'https://tokenhub.tencentmaas.com' });
});
