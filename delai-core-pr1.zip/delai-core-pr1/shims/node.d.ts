// PR1 搬迁脚手架：沙盒无 @types/node，这里只声明被搬迁代码实际用到的 Node API。
// 不是实现、不改业务逻辑；本机若安装 @types/node，可删除本文件并在 tsconfig 里去掉 shims。
// 注意：AbortSignal 由 lib.dom.d.ts 提供，此处不重复声明。

type Buffer = Uint8Array;

declare namespace NodeJS {
  type Timeout = ReturnType<typeof setTimeout>;
}

declare module 'node:https' {
  export interface ClientRequest {
    on(event: string, cb: (...args: any[]) => void): void;
    write(chunk: string): void;
    end(): void;
    destroy(err?: Error): void;
  }
  export interface IncomingMessage {
    statusCode?: number;
    setEncoding(enc: string): void;
    on(event: 'data', cb: (chunk: any) => void): void;
    on(event: 'end' | 'error', cb: (...args: any[]) => void): void;
  }
  export function request(
    url: string,
    options: any,
    cb?: (res: IncomingMessage) => void,
  ): ClientRequest;
}

declare module 'node:string_decoder' {
  export class StringDecoder {
    constructor(encoding?: string);
    write(buf: Buffer): string;
    end(): string;
  }
}

declare module 'node:test' {
  export interface TestOptions {
    todo?: boolean | string;
    skip?: boolean | string;
  }
  export function test(name: string, options: TestOptions, fn: () => void | Promise<void>): void;
  export function test(name: string, fn: () => void | Promise<void>): void;
}

declare module 'node:assert/strict' {
  const assert: {
    equal(actual: unknown, expected: unknown, msg?: string): void;
    notEqual(actual: unknown, expected: unknown, msg?: string): void;
    deepEqual(actual: unknown, expected: unknown, msg?: string): void;
    ok(value: unknown, msg?: string): void;
    throws(fn: () => void, matcher?: RegExp | unknown, msg?: string): void;
  };
  export default assert;
}
