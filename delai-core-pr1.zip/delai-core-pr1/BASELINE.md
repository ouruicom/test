# PR1 基线报告 · 真实编译 / 测试数字

> 2026-11-03 · 由沙盒实际执行生成，**不是估算、不是从文档推导**。
> 对应 `decision-q1-tos.md` v1.3 §8.2 第 1 步「先留基线」。

---

## 1. 执行环境与方法

| 项 | 值 |
|---|---|
| Node | v20.19.5 |
| 编译器 | TypeScript **5.6.3**（`tools/ts/lib/tsc.js`，离线自带，非 npx 推断） |
| 命令 | `node tools/ts/lib/tsc.js --noEmit -p tsconfig.json --pretty false` |
| tsconfig | `strict` + `noUncheckedIndexedAccess` + `noUnusedLocals` + `noUnusedParameters`（按文心本轮建议开启） |
| 单测 | `node --test dist/test/*.test.js`（Node 内置 test runner，零第三方依赖） |

`noEmitOnError` 默认 false，所以带错误也能编译出 `dist/` 供运行时测试——**这正是本次能发现两条运行时缺陷的原因**。

---

## 2. 类型检查基线：5 条存量错误

`baseline/tsc-errors.txt` 全文：

```
src/engine.ts(29,40): error TS2339: Property 'customerGlossaryHit' does not exist on type 'TranslateOpts'.
src/engine.ts(31,9): error TS2339: Property 'wantOfficialContext' does not exist on type 'TranslateOpts'.
src/engine.ts(48,26): error TS2339: Property 'buildMessages' does not exist on type 'HunyuanEngine'.
src/engine.ts(76,62): error TS2554: Expected 1-2 arguments, but got 0.
src/queue.ts(23,5): error TS2322: Type 'string | undefined' is not assignable to type 'string | null'.
```

逐条：

| # | 错误 | 来源 / 意义 |
|---|---|---|
| 1–2 | `customerGlossaryHit` / `wantOfficialContext` 不在 `TranslateOpts` | **文心 P1-3**，原判断成立：`selectRoute()` 读两个从未声明的字段，`tsc --noEmit` 根本过不了 |
| 3 | `this.buildMessages` 未定义 | **本 PR 新发现**。`HunyuanEngine.buildBody()` 调用了一个类里不存在的方法，文档 §12.5 只说「buildMessages(o, text)」但没给实现，也没说是类方法 |
| 4 | `keyRotator.penalize(/* 当前 key */)` 缺必填参数 | **本 PR 新发现**。原文把参数写成注释占位，代码不可编译 |
| 5 | `avail[this.idx % avail.length]` 可能是 `undefined` | **开启 `noUncheckedIndexedAccess` 后才暴露**。`KeyRotator.next()` 声明返回 `string \| null`，实际可能返回 `undefined`。这条恰好证明文心建议开这个开关是对的 |

**关于文心「tsc 只能关 P1-3 一条」的判断**：实测 tsc 一共暴露了 4 个编译期问题（P1-3 的两个字段 + 2 个本 PR 新发现）+ 1 个严格模式新增问题。范围比它说的略大，但**结论不变**：下面这些逻辑缺陷 tsc 一条都抓不到。

**实测确认文心另一判断**：`Bearer ${keyRotator.next()}` 在 `string | null` 下**不报错**——模板字符串插值允许 `null`，P0-3 只能靠单测/类型收窄关闭。

---

## 3. 单测：28 个 / 12 pass / 0 fail / 16 todo

```
# tests 28
# pass 12
# fail 0
# todo 16
```

- `test/characterization.test.ts`：12 条**能跑且通过**，断言的是 PR1 搬迁后的当前行为（含"把缺陷现状钉住"的用例）。
- `test/pending.test.ts`：16 条 `todo`，每条对应一个待修缺陷，写清修法与用例编号。按 §8.1 不阻断 CI。
- `scripts/typecheck-gate.mjs`：门禁 PASS（错误集合与基线一致）；第二次运行时我曾漏写 `assert.throws` 的 shim 声明，**门禁立刻报「新增 1 条」并拒绝通过**——这条实测证明基线门禁不是摆设。
- `.github/workflows/core.yml` 的静态扫描 PASS：无 `autoSend` / `autoSubmit` 入口（用例 73 雏形）。

---

## 4. 运行时新发现 2 条（编译器抓不到，文心 18 条里也没有）

第一次跑单测时这 2 条是**红灯**，现已改写为「现状固化」断言，并登记进 `pending.test.ts`：

**① `TranslateQueue` 同 key 去重在 in-flight 阶段完全失效。**
`push()` 的判重只检查 `this.queue` 里残留的 job，但 `pump()` 会立即把 job `shift()` 出去开跑。连续推 2 条同 key → 队列已空 → 第二次不合并。实测：推 5 条（含 2 条重复），**5 条全部执行**，不是期望的 3 条。
> 影响：刷屏时"相同文本天然命中缓存"（§4.4 调度规则）这句话在队列层不成立，只能靠下游 SQLite 缓存兜。8 账号场景会放大成重复 API 请求。

**② `buildBody()` 在 chat 路径运行时抛 `this.buildMessages is not a function`。**
与基线错误 #3 同一根因，运行时二次印证。也就是说**当前 `HunyuanEngine` 连一次非流式翻译都发不出去**。

---

## 5. 文档内部矛盾 3 处（本 PR 顺带核出）

| # | 矛盾 | 性质 |
|---|---|---|
| **A（最要紧）** | `plan-v1.8.md` §4.4 第 1179 行：「跨账号共享：`scope=global` 的缓存天然跨账号共享（**key 不含 account_id，符合预期**）」 vs `decision-q1-tos.md` v1.2/v1.3 把「cacheKey 不含 accountId」定性为**真漏网 + 隐私问题**，T9.6 要求补键 | **决策冲突，需拍板**：Q3 字段级加密下译文缓存到底按不按账号隔离。补键会让"高频话术跨账号秒回"失效，并触发全量旧缓存失效。这不是代码问题，是产品口径 |
| B | §12.5 文字要求「`TranslatorProvider` 必须实现 `buildChatBody` / `buildOpenApiBody` 两套构建器，不要写成一个函数里加 if」，但给出的 `HunyuanEngine` 仍是单个 `buildBody()` 里三元分派，且调用了未定义的 `this.buildMessages` | 文档与代码不一致 |
| C | §4.4 调度规则把「队列去重」与「缓存去重」混成一句「相同文本天然命中缓存」；实测队列去重失效（见 §4） | 表述含糊导致误判 |

> 矛盾 A 建议在下一次与文心对齐时单独提出来——它会直接改变 T9.6 的实现方式，越早定越省事。

---

## 6. 占位清单（PR1 未接真实实现，逐个登记）

`src/runtime.ts` / `src/env.ts` / `shims/node.d.ts` 全部是搬迁脚手架，不是业务实现：

`diagnostics.set/inc`、`viewManager.isActive`、`settings.get`、`md5`（当前是 FNV-1a 占位，**不是真 md5**）、`glossaryLastUpdated`、`buildContext`、`buildMessages`、`CA_POOL`、`BASE`、`defaultCaps`（§0 未实测前全为 false）、`keyRotator`（空数组构造 → 恒返回 null）、`translateQueue`、Node API 最小类型声明。

> `md5` 是占位这件事要留意：它不影响"键形状"类单测，但接真实 SQLite 前必须换成 crypto 的 md5，否则跨版本缓存键会变。

---

## 7. PR2+ 建议顺序（按 §8.2「搬迁与改动分开」）

每个 PR 只做一件事，便于 revert；每修一条就把对应 `todo` 去掉、更新 `baseline/tsc-errors.txt`：

| PR | 内容 | 关闭 |
|---|---|---|
| PR2 | 修 5 条编译期错误（两个字段、buildMessages、penalize、`string\|undefined`） | 基线错误清零；P1-3、P1-5 |
| PR3 | `TranslateQueue`：in-flight 去重 + T9.5 round-robin + 每账号在队上限 + P0-1 比较符 + P0-4 onStable 接线 | P0-1、P0-4、T9.5、运行时新发现① |
| PR4 | `cacheKey`：补 `accountId` / `context` / `style` + `cache_version` 迁移 | P0-2、v1.3 新缺陷、T9.6（**需先定矛盾 A**） |
| PR5 | `http-client`：绝对 deadline、响应体上限、3xx、aborted 前置检查 | P1-1、P1-2 |
| PR6 | `engine.call()`：`string\|null` 收窄显式抛 `AuthError`；`normalizeContext` 接线 | P0-3、P1-4、运行时新发现② |

长稳与真机用例（74 / 79 / 85）始终走发布检查单，不进 CI。

---

## 8. 本 PR 的边界（重申）

- **不改 `plan-v1.8.md`、不改 `decision-q1-tos.md` v1.3、不改 `s3-env-baseline.md`**。
- 不修任何逻辑缺陷、不编性能数字、不假称"核心闭环已通"。
- 不出新的文档版本；本文件只是代码仓库的基线报告。
