// PR1 搬迁脚手架：把 §12.5 call() 里引用的全局单例装配成模块导出。
// 原文是 `keyRotator.next()` / `translateQueue.onThrottle()` 这类裸全局引用，
// 搬迁成模块时必须显式 import；这是路径修正，未改变任何调用逻辑。
// ⚠️ keyRotator 用空数组构造 → next() 恒返回 null，正好把 P0-3「Bearer null」保留在基线里。

import { KeyRotator, TranslateQueue } from './queue';

export const keyRotator = new KeyRotator([]);
export const translateQueue = new TranslateQueue();
