// PR1 搬迁脚手架：plan-v1.8.md 里被引用、但散落在其它章节/未给出实现的外部符号。
// 这些是「让搬迁后的代码可编译运行」的最小占位，不是业务逻辑修复。
// 每个占位在 BASELINE.md 里都有登记，属于后续 PR 要接真实实现的地方。

import type { ContextTurn, TranslateOpts, ApiCaps } from './types';

export const diagnostics = {
  set(_key: string, _value: unknown): void { /* 接 §4.6.7 诊断面板 */ },
  inc(_key: string, _by = 1): void { /* 接 §4.6.7 诊断面板 */ },
};

export const viewManager = {
  isActive(_accountId: string): boolean { return false; },   // 接 §3.1 WebContentsView
};

export const settings = {
  get(_key: string): string | undefined { return undefined; },  // 接 §4.7 SQLite settings 表
};

// ⚠️ 占位哈希，不是真 md5。仅用于「键形状」类测试；接 §4.4 真实 md5 时替换。
export function md5(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}

export function glossaryLastUpdated(_scope: string): string { return '0'; }  // 接 glossary.updated_at

export function buildContext(turns?: ContextTurn[]): ContextTurn[] {
  return turns ?? [];   // 接 §12.3 A1（3 轮 / 2000 字符封顶）
}

export function buildMessages(
  _o: TranslateOpts,
  _text: string,
): Array<{ role: string; content: string }> {
  return [];            // 接 §12.5 buildMessages（system=术语+风格+背景, user=原文）
}

export const CA_POOL: Buffer[] = [];                        // 接 §4.2 R1 方式 B
export const BASE = 'https://tokenhub.tencentmaas.com';     // 接配置

export const defaultCaps: ApiCaps = {
  // §0 七项实测前，全部按「不支持」保守取值
  openApiEndpointExists: false,
  modelSupportsOpenApi: {
    'hy-mt2-lite': false,
    'hy-mt2-plus': false,
    'hy-mt2-pro': false,
  },
  referencesAcceptTerms: false,
  contextFieldConfirmed: false,
};
