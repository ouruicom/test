// 搬迁自 plan-v1.8.md §4.4（1101-1176 行，LruSet / glossaryScopeKey / cacheKey / globalGlossaryVersion）。
// 仅补 export / import，逐行照搬。
// ⚠️ 保留已知缺陷：
//   P0-2  cacheKey 不含 context / style。
//   v1.3  cacheKey 不含 accountId（A 号原文可被 B 号命中）。
//   注意：plan-v1.8.md §4.4 第 1179 行写「跨账号共享：key 不含 account_id，符合预期」，
//         与 decision-q1-tos.md v1.2 把它定性为「真漏网」直接矛盾 —— 见 BASELINE.md §4。
//   T9.6  补 accountId 会导致旧缓存全量失效，迁移方案未实现。

import { md5, settings, glossaryLastUpdated } from './runtime';

export class LruSet {
  constructor(private max = 3000) {}
  private map = new Map<string, true>();
  // v1.7.3：命中也要提升新鲜度。
  has(k: string) {
    if (!this.map.has(k)) return false;
    this.map.delete(k); this.map.set(k, true);   // 移到末尾
    return true;
  }
  add(k: string) {
    this.map.delete(k); this.map.set(k, true);
    if (this.map.size > this.max) {
      this.map.delete(this.map.keys().next().value!);
    }
  }
}

export function globalGlossaryVersion(): string {
  const v = settings.get('glossary_version_global');
  return /^\d+$/.test(v ?? '') ? v! : '1';    // 缺失或非法 → 回落 '1'
}

export function glossaryScopeKey(scope: string): string {
  if (scope === 'global') return `g${globalGlossaryVersion()}`;
  // 客户级：用该客户术语表最近更新时间做版本，避免影响全局缓存
  return `c${scope}:${glossaryLastUpdated(scope)}`;
}

export function cacheKey(p: {
  engine: string; model: string; from: string; to: string;
  text: string; scope: string;
}): string {
  return md5(`${p.engine}|${p.model}|${p.from}|${p.to}|${glossaryScopeKey(p.scope)}|${p.text}`);
}
