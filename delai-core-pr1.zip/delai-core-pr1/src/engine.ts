// 搬迁自 plan-v1.8.md §12.5（2671-2780 行）。仅补 export / import，逐行照搬。
// ⚠️ 保留已知缺陷（本 PR 不修）：
//   P1-3  selectRoute 读 o.customerGlossaryHit / o.wantOfficialContext，TranslateOpts 无此字段 → TS2339
//   P1-4  normalizeContext() 定义了但全文零调用点，上下文翻译静默失效
//   P0-3  `Bearer ${keyRotator.next()}`，全熔断时会发出 "Bearer null"
//   TS2554 call() 里 keyRotator.penalize(/* 当前 key */) 缺必填参数
//   注：原文写「TranslatorProvider 要实现 buildChatBody / buildOpenApiBody 两套构建器」，
//       但给出的 HunyuanEngine 仍是单个 buildBody() 里加三元分派 —— 文档内部矛盾，见 BASELINE.md §4。

import type { TranslateOpts, TranslatorProvider, ApiCaps } from './types';
import { HttpError, httpJson, httpStream } from './http-client';
import { keyRotator, translateQueue } from './env';
import { CA_POOL, BASE, buildContext, defaultCaps } from './runtime';

// 引擎层归一化：两条路线各取所需，调用方只管往上塞 turns
// ⚠️ v1.7.5：官方只说明 context 是 string「用于让译文更连贯」，并未规定
// "user:/assistant:" 角色前缀格式。下面这个拼法是【暂定实现】，须经 §0 第 7 项实测确认。
export function normalizeContext(o: TranslateOpts, route: 'openapi' | 'chat') {
  const turns = buildContext(o.contextTurns);        // 3 轮 / 2000 字符封顶，见 §12.3 A1
  return route === 'openapi'
    ? { text: turns.map(t => `${t.role}: ${t.text}`).join('\n') }   // 待实测：角色前缀格式
    : { turns };                                                      // chat 端点：拼进 messages
}

export function selectRoute(o: TranslateOpts, caps: ApiCaps): 'openapi' | 'chat' {
  // 任一能力不满足 → 回退 chat（功能不丢，仅走 prompt 内嵌）
  if (!caps.openApiEndpointExists) return 'chat';        // §0 第 2 项：端点不存在
  if (!caps.modelSupportsOpenApi[o.model ?? 'hy-mt2-lite']) return 'chat';
  if (!caps.referencesAcceptTerms && o.customerGlossaryHit) return 'chat';   // 客户级术语
  if ((o.glossaryIds?.length ?? 0) > (caps.glossaryIdLimit ?? 10)) return 'chat';
  if (o.wantOfficialContext && !caps.contextFieldConfirmed) return 'chat';
  return 'openapi';
}

export class HunyuanEngine implements TranslatorProvider {
  private caps: ApiCaps = defaultCaps;   // 由 §0 七项实测结果在启动时注入

  route(o: TranslateOpts): 'openapi' | 'chat' {
    return selectRoute(o, this.caps);
  }

  buildBody(o: TranslateOpts, text: string): unknown {
    return this.route(o) === 'openapi'
      ? { model: o.model, text, target: o.to, source: o.from,
          context: o.contextText, glossary_ids: o.glossaryIds,
          references: o.references, stream: o.stream ?? false }
      : { model: o.model, stream: o.stream ?? false,
          messages: this.buildMessages(o, text) };
  }

  // ⚠️ 原文调用 this.buildMessages(o, text)，但 HunyuanEngine 全文未定义该方法。
  //    PR1 不补实现（补了就等于改逻辑），让 tsc 如实报 TS2339。见 BASELINE.md §4。

  // 流式与非流式共用同一条出站管道
  async call(o: TranslateOpts, text: string, ctx: {
    requestId: string;                 // 幂等键
    onDelta?: (s: string) => void;
  }) {
    const body = JSON.stringify(this.buildBody(o, text));
    const common = {
      headers: { Authorization: `Bearer ${keyRotator.next()}` },   // Content-Type 由 http-client 强制
      body, ca: CA_POOL,
      signal: o.signal,
    };
    const url = this.route(o) === 'openapi'
      ? `${BASE}/v1/api/translations` : `${BASE}/v1/chat/completions`;
    try {
      return ctx.onDelta
        ? await new Promise<string>((res, rej) => httpStream(url, {
            ...common, requestId: ctx.requestId,
            idleTimeoutMs: 5_000, deadlineMs: 15_000,
          }, { onDelta: ctx.onDelta!, onDone: res, onError: rej }))
        : (await httpJson(url, { ...common, timeoutMs: 8_000 })).json;
    } catch (e) {
      if (e instanceof HttpError) {
        if (e.status === 401 || e.status === 403) keyRotator.penalize(/* 当前 key */);
        else if (e.retryable) translateQueue.onThrottle();
      }
      throw e;
    }
  }
}
