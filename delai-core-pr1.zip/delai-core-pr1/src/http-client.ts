// 搬迁自 plan-v1.8.md §4.2（631-696 行）+ §4.2.1（712-842 行）。
// 机械调整（不属于逻辑改动）：
//   1) 两个代码块原本共用同一个文件名 http-client.ts，合并为一个模块；
//   2) 补 export（HttpError / commonHeaders / httpJson / httpStream / StreamHandlers）；
//   3) 原文 `import type http from 'node:http'; let req!: http.ClientRequest`
//      改为 `import type { ClientRequest } from 'node:https'`（shims 只在 node:https 声明该类型）。
// 除此之外逐行照搬，**保留全部已知缺陷**（无响应体上限 / 3xx 未处理 / httpJson 无绝对 deadline / P1-1）。

import https from 'node:https';
import type { ClientRequest } from 'node:https';
import { StringDecoder } from 'node:string_decoder';

// ⚠️ v1.8 C-2：结构化错误。429 退避、401/403 熔断、R19 自适应全部读 status，
// 禁止再用正则去解析 new Error("HTTP 429: ...") 的字符串。
export class HttpError extends Error {
  constructor(
    public readonly status: number,
    public readonly body: string,
    public readonly retryable: boolean,
  ) { super(`HTTP ${status}: ${body.slice(0, 200)}`); }
  static from(status: number, body: string) {
    return new HttpError(status, body,
      status === 429 || status === 408 || status >= 500);   // 401/403 不重试，直接熔断
  }
}

export function commonHeaders(h?: Record<string, string>): Record<string, string> {
  // ⚠️ v1.8 C-3：内部强制，不靠调用方传；漏传即 400 的坑在这里堵死
  return { 'Content-Type': 'application/json', ...h };
}

export async function httpJson(url: string, options: {
  method?: string;
  headers?: Record<string, string>;
  body?: string;
  timeoutMs?: number;
  ca?: Buffer[];
  signal?: AbortSignal;            // ⚠️ v1.8 C-4：A1「取消翻译」要能中断在途请求
}): Promise<{ status: number; json: any }> {
  return new Promise((resolve, reject) => {
    const req = https.request(url, {
      method: options.method ?? 'GET',
      headers: commonHeaders(options.headers),
      ca: options.ca,               // 不再关闭校验；缺省走系统根证书
      timeout: options.timeoutMs ?? 8000,   // 注意：socket 空闲超时，非总时长
    }, (res) => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', (c) => (data += c));
      res.on('end', () => {
        if (res.statusCode && res.statusCode >= 400) {
          return reject(HttpError.from(res.statusCode, data));
        }
        try {
          resolve({ status: res.statusCode ?? 0, json: JSON.parse(data) });
        } catch {
          reject(new Error('响应非JSON: ' + data.slice(0, 200)));
        }
      });
    });
    req.on('timeout', () => req.destroy(new HttpError(408, 'timeout', true)));
    req.on('error', reject);

    // ⚠️ v1.8 C-5：结算时必须解绑，否则长跑进程每次请求都累积一个监听器
    const onAbort = () => req.destroy(new Error('已取消'));
    const cleanup = () => options.signal?.removeEventListener('abort', onAbort);
    options.signal?.addEventListener('abort', onAbort, { once: true });
    req.on('close', cleanup);

    if (options.body) req.write(options.body);
    req.end();
  });
}

export type StreamHandlers = {
  onDelta: (text: string) => void;
  onDone: (full: string) => void;
  onError: (e: Error) => void;
};

export function httpStream(url: string, options: {
  headers?: Record<string, string>;
  body?: string;
  idleTimeoutMs?: number;     // v1.8：socket 空闲超时（心跳会不断重置它）
  deadlineMs?: number;        // v1.8：绝对总时长上限，不受心跳影响
  ca?: Buffer[];              // ← 与 httpJson 同一份 CA 配置，R1 不失效
  signal?: AbortSignal;
  requestId: string;          // v1.8：幂等键，用于计费去重与译文回滚
}, h: StreamHandlers): void {
  let req!: ClientRequest;

  // ⚠️ v1.8 C-1：Node 的 https.request({timeout}) 是【socket 空闲超时】，不是总时长。
  // 服务端只要持续发 `: ping` 心跳，这个计时器就被反复重置，流永不结束 →
  // 并发槽位被永久占用 → 整个 TranslateQueue 假死。必须另设绝对 deadline。
  const deadlineAt = Date.now() + (options.deadlineMs ?? 15_000);
  let deadlineTimer: NodeJS.Timeout | undefined;

  const onAbort = () => fail(new Error('已取消'));
  const cleanupAbort = () => options.signal?.removeEventListener('abort', onAbort);
  options.signal?.addEventListener('abort', onAbort, { once: true });

  // 单次结算守卫：idle timeout / deadline / abort / res error / req error / [DONE]
  // 可能同时触发，否则 onDone 与 onError 双调用，注入层出现"既成功又失败"的竞态
  let settled = false;
  const finish = (fn: () => void) => {
    if (settled) return;
    settled = true;
    if (deadlineTimer) clearTimeout(deadlineTimer);
    cleanupAbort();                    // ⚠️ v1.8 C-5：结算即解绑，避免长跑累积监听器
    fn();
  };
  const fail = (e: Error) => finish(() => { req?.destroy(); h.onError(e); });

  // 每次收到数据后按【绝对截止时间】重算剩余时间，心跳无法把它推后
  const armDeadline = () => {
    const remaining = Math.max(1, deadlineAt - Date.now());
    if (deadlineTimer) clearTimeout(deadlineTimer);
    deadlineTimer = setTimeout(
      () => fail(new HttpError(408, 'stream deadline exceeded', false)), remaining);
  };

  // ⚠️ v1.7.6：显式 StringDecoder 处理跨 chunk 的多字节 UTF-8 序列。
  // 禁止改成 Buffer 拼接或 chunk.toString('utf8') 逐块转换。
  const decoder = new StringDecoder('utf8');
  let carry = '';                 // 未成行的文本残留
  let eventLines: string[] = [];  // 当前 SSE 事件累积的行
  let full = '';

  const dispatchEvent = () => {
    if (!eventLines.length) return;
    // 标准 SSE：以【空行】为事件边界；同一事件内多个 data: 行按 \n 连接后再解析
    const dataParts = eventLines
      .filter(l => l.startsWith('data:'))
      .map(l => l.slice(5).replace(/^ /, ''));   // 去掉规范中可选的一个前导空格
    eventLines = [];
    if (!dataParts.length) return;
    const payload = dataParts.join('\n').trim();
    if (payload === '[DONE]') {
      finish(() => { req.destroy(); h.onDone(full); });   // 主动结束，不依赖连接关闭
      return;
    }
    try {
      const j = JSON.parse(payload);
      if (j?.error) { fail(new Error(`流式返回错误: ${JSON.stringify(j.error)}`)); return; }
      const d = j.choices?.[0]?.delta?.content ?? j.delta ?? j.text ?? '';
      if (d) { full += d; h.onDelta(d); }
    } catch { /* 注释行 / keep-alive / 非 JSON 心跳，安全跳过 */ }
  };

  const feed = (s: string) => {
    carry += s;
    const lines = carry.split('\n');
    carry = lines.pop() ?? '';                    // 保留不完整的尾行
    for (const raw of lines) {
      const line = raw.replace(/\r$/, '');        // 兼容 \r\n
      if (line === '') { dispatchEvent(); continue; }   // ← 空行分帧，不是按单行解析
      if (line.startsWith(':')) continue;               // 注释 / keep-alive
      eventLines.push(line);                            // event:/id:/retry:/data: 都收下
    }
  };

  armDeadline();                         // 请求发出前就启动绝对计时

  req = https.request(url, {
    method: 'POST',
    // ⚠️ v1.8 C-3：Content-Type 由 commonHeaders 强制，Accept 由流式覆盖
    headers: { ...commonHeaders(options.headers), Accept: 'text/event-stream' },
    ca: options.ca,
    timeout: options.idleTimeoutMs ?? 5_000,   // 仅 socket 空闲超时；总时长看 armDeadline
  }, (res) => {
    if (res.statusCode && res.statusCode >= 400) {
      const errDec = new StringDecoder('utf8');
      let err = '';
      res.on('data', (c: Buffer) => (err += errDec.write(c)));
      // ⚠️ v1.8 C-2：抛结构化 HttpError
      res.on('end', () => fail(HttpError.from(res.statusCode!, err)));
      return;
    }
    res.on('data', (chunk: Buffer) => { armDeadline(); feed(decoder.write(chunk)); });
    res.on('end', () => {
      const tail = decoder.end();          // 冲出末端不完整字节（若有）
      if (tail) feed(tail);
      if (carry.trim()) { eventLines.push(carry); carry = ''; }
      dispatchEvent();                     // 处理最后一个无空行结尾的事件
      finish(() => h.onDone(full));        // [DONE] 已结算则不再触发
    });
    res.on('error', fail);
  });
  req.on('timeout', () => fail(new HttpError(408, 'idle timeout', true)));
  req.on('error', fail);
  if (options.body) req.write(options.body);
  req.end();
}
