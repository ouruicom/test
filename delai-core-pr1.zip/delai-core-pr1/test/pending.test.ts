// §8.1：本文件全部为 TODO 用例，CI 不因它们失败，但「缺陷清单」随代码一起版本化。
// PR2+ 修 bug 时：把对应 todo 去掉、让断言描述【正确行为】、再改 src/，
// 这样每个缺陷都有一条从「记录」到「关闭」的可审计路径。
//
// 编号沿用文心 rev.2 的 P0/P1 与 decision-q1-tos.md v1.3 的 T9.x。

import { test } from 'node:test';

const TODO = (why: string) => ({ todo: why });

test('P0-1 背压比较符写反：b.priority - a.priority 为降序，splice 切掉 P0',
  TODO('queue.ts applyBackpressure：改为升序排序或显式保留 P0；用例 70 / 86'),
  () => { /* 修后断言：8 账号刷屏 300 条时 P0 一条不丢 */ });

test('P0-2 cacheKey 漏 context / style：不同上下文与风格命中同一旧译文',
  TODO('cache.ts：键补 contextDigest 与 style；用例 28'),
  () => { /* 修后断言：同 text 不同 context/style → 不同 key */ });

test('P0-3 全熔断时发出 "Bearer null"；需显式抛 AuthError 且出站函数不被调用',
  TODO('engine.ts call()：next(): string|null 收窄；用例 68。注意 tsc 抓不到模板插值 null'),
  () => { /* 修后断言：httpJson/httpStream 未被调用 + UI 收到 quotaExhausted（不是「且返回 401」） */ });

test('P0-4 onStable() 全文零调用点：并发只降不升，三次 500 抖动后锁死在 1',
  TODO('调度层：稳定 60s 后调用 onStable；用例 68'),
  () => { /* 修后断言：连续成功后 maxConcurrent 回升 */ });

test('P1-1 已 abort 的 AbortSignal 传入 httpJson 仍会发出请求',
  TODO('http-client.ts：请求前检查 signal.aborted；用例未编号'),
  () => { /* 修后断言：不发起 https.request */ });

test('P1-2 httpJson 无绝对 deadline / 无响应体上限 / 3xx 未处理',
  TODO('http-client.ts：补 deadline + maxResponseBytes + 3xx 显式失败；C-1 只修了流式一半'),
  () => { /* 修后断言：超大响应体截断、302 不当 JSON 解析、心跳不拖死 */ });

test('P1-3 selectRoute 读 TranslateOpts 上不存在的两个字段 → TS2339',
  TODO('由 typecheck 基线直接暴露（见 baseline/tsc-errors.txt），修后从基线删除'),
  () => { /* 编译期缺陷，不由单测关闭 */ });

test('P1-4 normalizeContext() 定义但零调用；contextText / contextTurns 均未进请求体',
  TODO('engine.ts：buildBody 按 route 分派调用 normalizeContext'),
  () => { /* 修后断言：openapi body 含拼接后的 context 字段 */ });

test('P1-5 HunyuanEngine 调 this.buildMessages 但类里没定义 → TS2339',
  TODO('本 PR 搬迁时发现的原文缺陷；补实现或改为导入的 buildMessages'),
  () => { /* 编译期缺陷，不由单测关闭 */ });

test('v1.3 新缺陷：cacheKey 不含 accountId，A 号私聊原文可被 B 号命中（叠加 Q3 缓存不加密）',
  TODO('cache.ts：键补 accountId 或按账号分库；用例 84'),
  () => { /* 修后断言：同原文不同账号 → 不同 key */ });

test('T9.5 全局 FIFO 无按账号 round-robin / 每账号在队上限：1 号堆 200 条会饿死 8 号',
  TODO('queue.ts：全局队列 + 按账号轮转出队 + perAccountCap；用例 86'),
  () => { /* 修后断言：1 号灌 200 条时 8 号 P0 仍在有限周期内出队 */ });

test('T9.6 补 accountId 后旧缓存全量失效，缺 cache_version 迁移与重新预热',
  TODO('推荐「键 + 版本号」，不推荐按账号分库（与 §4.7.1 单连接 + WAL 约束冲突）；用例 87'),
  () => { /* 修后断言：升级后无跨号命中且高频话术秒回不退化 */ });

test('【PR1 运行时新发现】TranslateQueue 同 key 去重只在「队列残留」生效，in-flight 不参与',
  TODO('push() 在 pump() 前判重，但 pump 立即 shift 出队；需维护 in-flight key 集合。文心 18 条未列'),
  () => { /* 修后断言：连推 2 条同 key → 只执行 1 次（characterization 用例同步改回 3） */ });

test('【PR1 运行时新发现】buildBody 在 chat 路径抛 this.buildMessages is not a function',
  TODO('与 TS2339 同一根因，运行时已复现；characterization 里已固化为 throws'),
  () => { /* 修后断言：body.messages 为数组且含 system/user */ });

test('T1 出站「预览确认」尚未落到代码：autoSend 静态扫描用例 73 未实现',
  TODO('PR 后续：全局搜索配置无 autoSend/autoSubmit 入口'),
  () => { /* 静态扫描 */ });

test('T10.1 / T10.2 字段级加密、safeStorage backend 白名单、-wal/-shm 清理策略',
  TODO('涉及 SQLite/safeStorage，属集成层（§8.1 集成层），不在 packages/core 单测范围'),
  () => { /* 集成测试 */ });
