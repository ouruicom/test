// §8.1「单测层」：CI 阻断。这里断言的是【PR1 搬迁后的当前行为】，
// 目的是把代码钉住——下一个 PR 修 bug 时会变红，必须连同本文件一起更新，
// 防止「文档说改了、代码没动」再次发生。

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { HttpError, commonHeaders } from '../src/http-client';
import { LruSet, cacheKey, globalGlossaryVersion } from '../src/cache';
import { KeyRotator, TranslateQueue, priorityOf } from '../src/queue';
import { selectRoute, normalizeContext, HunyuanEngine } from '../src/engine';
import { defaultCaps } from '../src/runtime';
import type { Job } from '../src/queue';
import type { TranslateOpts } from '../src/types';

test('HttpError.from：429/408/5xx 可重试，401/403/400 不重试', () => {
  assert.equal(HttpError.from(429, '').retryable, true);
  assert.equal(HttpError.from(408, '').retryable, true);
  assert.equal(HttpError.from(503, '').retryable, true);
  assert.equal(HttpError.from(401, '').retryable, false);
  assert.equal(HttpError.from(403, '').retryable, false);
  assert.equal(HttpError.from(400, '').retryable, false);
  assert.equal(HttpError.from(429, 'x').status, 429);
});

test('commonHeaders：强制 Content-Type，且允许调用方覆盖', () => {
  assert.deepEqual(commonHeaders(), { 'Content-Type': 'application/json' });
  assert.deepEqual(commonHeaders({ Authorization: 'Bearer k' }), {
    'Content-Type': 'application/json', Authorization: 'Bearer k',
  });
});

test('LruSet：读命中提升新鲜度（修复 v1.7.3 的伪 LRU）', () => {
  const s = new LruSet(2);
  s.add('a'); s.add('b');
  assert.equal(s.has('a'), true);   // a 移到末尾
  s.add('c');                       // 淘汰最旧的 b
  assert.equal(s.has('a'), true, '热的 a 不应被挤掉');
  assert.equal(s.has('b'), false);
  assert.equal(s.has('c'), true);
});

test('globalGlossaryVersion：settings 缺失时回落 1（v1.5.2 R29 兜底）', () => {
  assert.equal(globalGlossaryVersion(), '1');
});

test('cacheKey：同输入稳定、改 model/scope/text 会变', () => {
  const base = { engine: 'hunyuan', model: 'hy-mt2-lite', from: 'en', to: 'zh',
                 text: 'MOQ?', scope: 'global' };
  assert.equal(cacheKey(base), cacheKey({ ...base }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, model: 'hy-mt2-pro' }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, text: 'shipping cost?' }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, scope: 'customer:alice' }));
});

test('【现状固化】cacheKey 不含 accountId / context / style —— 已知缺陷，见 pending', () => {
  const base = { engine: 'hunyuan', model: 'hy-mt2-lite', from: 'en', to: 'zh',
                 text: 'please confirm', scope: 'global' };
  // 当前签名里根本没有这三个字段，故不同上下文 / 不同账号必然得到同一把 key。
  // 这两条断言是「记录现状」，不是认可现状；修完 P0-2 / v1.3 后必须改本用例。
  assert.equal(cacheKey(base), cacheKey({ ...base }));
  assert.equal(typeof cacheKey(base), 'string');
});

test('KeyRotator：无可用 Key 返回 null；penalize 后进入冷却', () => {
  assert.equal(new KeyRotator([]).next(), null);
  const r = new KeyRotator(['k1', 'k2']);
  assert.equal(r.next(), 'k1');
  r.penalize('k1');
  assert.equal(r.next(), 'k2');
  r.penalize('k2');
  assert.equal(r.next(), null);
});

test('priorityOf：当前会话 P0；其余由 viewManager 决定 P1/P2', () => {
  assert.equal(priorityOf('a1', true), 0);
  assert.equal(priorityOf('a1', false), 2);   // runtime stub 恒 false
});

test('【现状固化】TranslateQueue 并发上限有效，但同 key 合并在 in-flight 阶段失效', async () => {
  const q = new TranslateQueue(2, 1, 8);
  let peak = 0;
  let running = 0;
  let calls = 0;
  const make = (key: string): Job => ({
    key, priority: 0, accountId: 'a1', enqueuedAt: Date.now(),
    run: async () => {
      calls++; running++; peak = Math.max(peak, running);
      await new Promise<void>(r => setTimeout(r, 5));
      running--;
    },
  });
  q.push(make('x')); q.push(make('x'));   // ← 期望合并，但 pump() 已把第一条 shift 出队列
  q.push(make('y')); q.push(make('z')); q.push(make('w'));
  await new Promise<void>(r => setTimeout(r, 60));
  // PR1 实测：5 条全部执行。去重只检查「队列里残留的」，不覆盖正在跑的任务。
  // 这是本 PR 运行时新发现的缺陷（文心 18 条里未列），见 pending.test.ts。
  assert.equal(calls, 5, '当前实现下同 key 不合并');
  assert.ok(peak <= 2, `峰值并发 ${peak} 应 <= 2`);
});

test('selectRoute：§0 未实测前全部能力为 false → 一律回退 chat', () => {
  const o: TranslateOpts = { to: 'zh' };
  assert.equal(selectRoute(o, defaultCaps), 'chat');
});

test('【现状固化】buildBody 调了不存在的 this.buildMessages —— 运行时抛错（与 TS2339 互证）', () => {
  const e = new HunyuanEngine();
  assert.equal(e.route({ to: 'zh' }), 'chat');
  assert.throws(
    () => e.buildBody({ to: 'zh', model: 'hy-mt2-lite' }, 'hello'),
    /this\.buildMessages is not a function/,
    'PR1 不补实现；修后本用例应改为断言 body.messages 为数组',
  );
});

test('normalizeContext：openapi 拼角色前缀，chat 返回结构化 turns', () => {
  const o: TranslateOpts = {
    to: 'zh',
    contextTurns: [{ role: 'user', text: 'MOQ?' }, { role: 'assistant', text: '500 pcs' }],
  };
  assert.deepEqual(normalizeContext(o, 'chat'), { turns: o.contextTurns });
  assert.equal(
    (normalizeContext(o, 'openapi') as { text: string }).text,
    'user: MOQ?\nassistant: 500 pcs',
  );
});
