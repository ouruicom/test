// PR1 实测发现：tsc 带存量错误时退出码为 2，会打断 CI 的编译步骤，
// 而 `noEmitOnError` 默认 false 其实已经产出了 dist/。
// 类型错误由 scripts/typecheck-gate.mjs 单独把关；这里只负责产出可运行的 JS。
// 用 Node 包装而不是 shell 的 `|| true`，保证 Windows / Linux 行为一致。

import { execFileSync } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';

const root = path.resolve(import.meta.dirname, '..');

let out = '';
try {
  out = execFileSync(
    process.execPath,
    ['tools/ts/lib/tsc.js', '-p', 'tsconfig.json', '--pretty', 'false'],
    { cwd: root, encoding: 'utf8' },
  );
} catch (e) {
  out = `${e.stdout ?? ''}${e.stderr ?? ''}`;
}

const n = out.split('\n').filter(l => /error TS\d+:/.test(l)).length;
console.log(`[build] tsc 报告 ${n} 条存量类型错误（由 typecheck-gate 把关），继续产出 JS`);

const required = [
  'dist/src/http-client.js', 'dist/src/queue.js', 'dist/src/cache.js',
  'dist/src/engine.js', 'dist/test/characterization.test.js',
];
const missing = required.filter(f => !fs.existsSync(path.join(root, f)));
if (missing.length) {
  console.error('[build] 缺少编译产物：', missing.join(', '));
  process.exit(1);
}
console.log('[build] PASS：dist/ 产物齐全');
