// §8.2 第 1 步「先留基线」的 CI 落地：
// 不做「零错误」门禁（存量错误会让 pipeline 永久标红 = 等于没有门禁），
// 改做「错误集合不得新增」——与 baseline/tsc-errors.txt 逐行比对，
// 新增或消失都要求显式更新基线文件，从而让每一次修复/劣化都进 PR 记录。
//
// 零依赖：直接用项目自带的 tools/ts/lib/tsc.js，无需 npm install。

import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const baselinePath = path.join(root, 'baseline', 'tsc-errors.txt');

let raw = '';
try {
  raw = execFileSync(
    process.execPath,
    ['tools/ts/lib/tsc.js', '--noEmit', '-p', 'tsconfig.json', '--pretty', 'false'],
    { cwd: root, encoding: 'utf8' },
  );
} catch (e) {
  raw = `${e.stdout ?? ''}${e.stderr ?? ''}`;
}

// 只保留诊断行，去掉绝对路径前缀与摘要行，保证跨机器可比对
const errors = raw
  .split('\n')
  .map(l => l.trim())
  .filter(l => /error TS\d+:/.test(l))
  .map(l => l.replace(/^[A-Za-z]:\\[^\s]*delai-core-pr1[\\/]/, ''))
  .sort();

if (!fs.existsSync(path.join(root, 'baseline'))) {
  fs.mkdirSync(path.join(root, 'baseline'), { recursive: true });
}

if (!fs.existsSync(baselinePath)) {
  fs.writeFileSync(baselinePath, errors.join('\n') + (errors.length ? '\n' : ''), 'utf8');
  console.log(`[gate] 基线已生成：${errors.length} 条存量错误 → baseline/tsc-errors.txt`);
  process.exit(0);
}

const prev = fs.readFileSync(baselinePath, 'utf8')
  .split('\n').map(l => l.trim()).filter(Boolean).sort();

const added = errors.filter(l => !prev.includes(l));
const removed = prev.filter(l => !errors.includes(l));

if (!added.length && !removed.length) {
  console.log(`[gate] PASS：错误集合与基线一致（${errors.length} 条存量错误，无新增、无消失）`);
  process.exit(0);
}

console.error(`[gate] 基线发生变化：新增 ${added.length} 条，消失 ${removed.length} 条`);
for (const l of added) console.error('  + ' + l);
for (const l of removed) console.error('  - ' + l);
console.error('[gate] 请确认是「修复」还是「劣化」，然后更新 baseline/tsc-errors.txt 再提交。');
process.exit(1);
