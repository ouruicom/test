# 变更记录（便于 revert 对照）

> 每个 PR 单独一节、只做一件事（§8.2）。`BASELINE.md` 是 **PR1 时点的历史快照，故意不改**——
> 留着它才能对照出「修复前 / 修复后」的真实数字差异。

---

## PR1 · 纯搬迁 + 基线（已完成）

把 `plan-v1.8.md` 的 §4.2 / §4.2.1 / §4.4 / §12.5 TS 片段搬进 `src/`，不改逻辑。

- `tsc --noEmit`：**5 条存量错误**
- 单测：**28 / 12 pass / 0 fail / 16 todo**
- 运行时新发现 3 条缺陷（队列 in-flight 去重失效、`buildBody` 抛错、CI 退出码 2）
- 详见 `BASELINE.md`

---

## PR2 · 修 5 条编译期错误，基线清零（当前版本）

**范围**：只修「不能编译」，不改任何业务行为。P0 系列逻辑缺陷一律留到 PR3–PR6。

### 改了 5 处

| # | 文件 | 改动 | 关闭 |
|---|---|---|---|
| 1 | `src/types.ts` | `TranslateOpts` 补 `customerGlossaryHit?: boolean` / `wantOfficialContext?: boolean`。两个字段是 §12.5 `selectRoute()` 第 2713/2715 行**已经在读、但接口漏声明**的；声明为可选，缺省时 falsy，路由行为与 PR1 完全一致 | P1-3（TS2339 ×2） |
| 2 | `src/engine.ts` | `this.buildMessages(o, text)` → 导入的 `buildMessages(o, text)`（`runtime.ts` 已有占位） | P1-5（TS2339）+ PR1 运行时新发现② |
| 3 | `src/engine.ts` | 把 `keyRotator.next()` 提取成 `const token`，catch 里 `keyRotator.penalize(token)` 补上必填参数（原文把参数写成注释占位） | TS2554 |
| 4 | `src/queue.ts` | `return k` → `return k ?? null`。`noUncheckedIndexedAccess` 下数组下标可能是 `undefined`；取模保证在范围内，`?? null` 是纯类型兜底 | TS2322 |
| 5 | 测试与基线 | `buildBody` 的 `throws` 固化断言改为「返回 messages 数组」；新增 1 条 `selectRoute` 用例验证两个新字段确实参与回退判定；关闭 3 条 todo；`baseline/tsc-errors.txt` 清空 | 关闭证据 |

> **没顺手改的**：`Bearer ${token}` 在 token 为 null 时仍会发出 `"Bearer null"`（P0-3，tsc 不报，留 PR6）；`normalizeContext()` 仍零调用（P1-4，留 PR4/PR6）；`buildMessages` 仍是返回 `[]` 的占位。
> **所以 PR2 之后引擎依然不能真正发翻译请求**——编译通过 ≠ 功能可用，这点必须写清楚。

### 门禁两阶段实测（这是本 PR 最有价值的证据）

旧基线还在时直接跑门禁，它**拒绝通过**并精确列出消失的 5 条：

```
[gate] 基线发生变化：新增 0 条，消失 5 条
  - src/engine.ts(29,40): error TS2339: Property 'customerGlossaryHit' ...
  - src/engine.ts(31,9): error TS2339: Property 'wantOfficialContext' ...
  - src/engine.ts(48,26): error TS2339: Property 'buildMessages' ...
  - src/engine.ts(76,62): error TS2554: Expected 1-2 arguments, but got 0.
  - src/queue.ts(23,5): error TS2322: Type 'string | undefined' ...
[gate] 请确认是「修复」还是「劣化」，然后更新 baseline/tsc-errors.txt 再提交。
退出码 1
```

清空基线后复跑：`[gate] PASS：错误集合与基线一致（0 条存量错误）`。

> 这证明 `typecheck-gate.mjs` 不是摆设：它同时能挡住「新增错误」和「悄悄改了代码却没更新基线」。

### 数字对照

| 项 | PR1 | PR2 |
|---|---|---|
| `tsc --noEmit` | 5 条错误 | **0 条，退出码 0** |
| 基线门禁 | PASS（5 条） | PASS（0 条） |
| 单测 | 28 / 12 pass / 16 todo | **26 / 13 pass / 0 fail / 13 todo** |
| 静态扫描（无 `autoSend`） | PASS | PASS |

> 总数从 28 降到 26 是故意的：3 条已关闭的 todo 从清单移除，1 条新用例加进 characterization。
> pass 12 → 13、todo 16 → 13，正好对得上。

### review 怎么核

```bash
node tools/ts/lib/tsc.js --noEmit -p tsconfig.json   # 应当无任何输出、退出码 0
node scripts/typecheck-gate.mjs                       # PASS（0 条）
node scripts/build.mjs                                # PASS
node --test dist/test/*.test.js                       # 13 pass / 0 fail / 13 todo
```

想 revert 到修复前：取仓库里的 `delai-core-pr1.zip`（PR1 快照），或 `git revert` 本 PR 的 5 处改动 + 恢复 `baseline/tsc-errors.txt` 那 5 行。

---

## 下一个：PR3（建议，未开工）

按 `BASELINE.md §7`：修 `TranslateQueue` 的 in-flight 去重、P0-1 背压比较符、P0-4 `onStable` 接线、T9.5 round-robin + 每账号在队上限。

**开工前建议先拍板 `BASELINE.md §5` 矛盾 A**（缓存 key 到底要不要含 `accountId`）——它决定 PR4 的实现方向，越早定越省事。
