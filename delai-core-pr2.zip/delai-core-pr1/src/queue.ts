// 搬迁自 plan-v1.8.md §4.4（985-1089 行）。仅补 export / import，逐行照搬。
// ⚠️ 保留已知缺陷：
//   P0-1 applyBackpressure 的比较符 b.priority - a.priority 是【降序】，
//        splice(MAX_QUEUE) 切掉的是 P0 而非 P2 —— 与注释「当前可见会话绝不丢」相反。
//   P0-4 onStable() 全文零调用点，并发只降不升。
//   T9.5 全局 FIFO 无按账号 round-robin / 每账号在队上限。
// 以上三个都不在本 PR 修，见 test/pending.test.ts 与 BASELINE.md。

import { diagnostics, viewManager } from './runtime';

export class KeyRotator {
  private idx = 0;
  private cooldown = new Map<string, number>();

  constructor(private keys: string[]) {}

  next(): string | null {
    const now = Date.now();
    const avail = this.keys.filter(k => (this.cooldown.get(k) ?? 0) <= now);
    if (!avail.length) return null;                 // 全部熔断
    const k = avail[this.idx % avail.length];
    this.idx++;
    // PR2：strict + noUncheckedIndexedAccess 下数组下标访问可能是 undefined。
    // 取模保证下标在范围内，`?? null` 是类型兜底，不改变任何运行行为。
    return k ?? null;
  }

  penalize(key: string, ms = 60_000) {              // 401/403/连续失败
    this.cooldown.set(key, Date.now() + ms);
  }
}

export type Priority = 0 | 1 | 2;   // 0=当前可见会话 1=同账号其它会话 2=后台账号

export interface Job {
  key: string;                // 文本去重键（同文本合并，不重复请求）
  priority: Priority;
  accountId: string;
  run: () => Promise<void>;
  enqueuedAt: number;
}

export class TranslateQueue {
  private queue: Job[] = [];
  private active = 0;
  private maxConcurrent: number;
  private readonly min: number;
  private readonly ceiling: number;
  private stableSince = Date.now();

  private readonly MAX_QUEUE = 200;       // 背压上限
  private readonly MAX_AGE_MS = 30_000;   // 排队超 30s 的旧任务直接作废

  constructor(initial = 4, min = 1, ceiling = 8) {
    this.maxConcurrent = initial;
    this.min = min;
    this.ceiling = ceiling;   // 上限以 §0 第 4 项实测为准，不写死 5
  }

  // 收到 429 / 连续超时 → 立即砍半，并记录不稳定
  onThrottle() {
    this.maxConcurrent = Math.max(this.min, Math.floor(this.maxConcurrent / 2));
    this.stableSince = Date.now();
    diagnostics.set('translate.concurrency', this.maxConcurrent);
  }

  // 稳定成功一段时间（建议 60s）→ 缓慢回升 +1，避免刚恢复又撞限流
  onStable() {
    if (Date.now() - this.stableSince < 60_000) return;
    this.maxConcurrent = Math.min(this.ceiling, this.maxConcurrent + 1);
    this.stableSince = Date.now();
    diagnostics.set('translate.concurrency', this.maxConcurrent);
  }

  push(job: Job) {
    // 同文本合并：已在队列里就直接丢弃（结果会由先到的那个任务写入共享缓存）
    if (this.queue.some(j => j.key === job.key)) return;
    this.queue.push(job);
    this.applyBackpressure();
    this.pump();
  }

  private applyBackpressure() {
    this.queue = this.queue.filter(j => {
      if (Date.now() - j.enqueuedAt < this.MAX_AGE_MS) return true;
      diagnostics.inc('translate.dropped.stale');
      return false;
    });
    if (this.queue.length <= this.MAX_QUEUE) return;
    // 超限：优先丢【后台账号】的旧任务，当前可见会话的任务绝不丢
    this.queue.sort((a, b) => b.priority - a.priority || b.enqueuedAt - a.enqueuedAt);
    const dropped = this.queue.splice(this.MAX_QUEUE);
    diagnostics.inc('translate.dropped.backpressure', dropped.length);
  }

  private pump() {
    // 优先级升序 → 同优先级按入队时间（FIFO，不饿死）
    this.queue.sort((a, b) => a.priority - b.priority || a.enqueuedAt - b.enqueuedAt);
    while (this.active < this.maxConcurrent && this.queue.length) {
      const job = this.queue.shift()!;
      this.active++;
      job.run().finally(() => { this.active--; this.pump(); });
    }
  }
}

// 优先级判定：主进程知道哪个 accountId 当前 visible
export function priorityOf(accountId: string, isCurrentConversation: boolean): Priority {
  if (isCurrentConversation) return 0;
  return viewManager.isActive(accountId) ? 1 : 2;
}
