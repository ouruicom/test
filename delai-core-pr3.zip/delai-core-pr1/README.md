# delai-core · 当前 PR3（队列层 4 条缺陷修复 + 矛盾 A 裁决落档）

> 对应 `decision-q1-tos.md` v1.3 §8.2。每个 PR 只做一件事，便于 revert。
>
> **当前状态（PR3）**：`tsc --noEmit` **0 错误**；基线门禁 PASS；单测 **25 / 17 pass / 0 fail / 8 todo**。
> PR3 关闭了 P0-1 / P0-4 / T9.5 / in-flight 去重 4 条队列缺陷；同包落档「缓存 key 不补 `accountId`」的用户裁决。
> **引擎仍不能真正发翻译请求**（`buildMessages` 仍是 `[]` 占位、`Bearer null` 与 `normalizeContext` 零调用未修，属 PR5–PR6）。
> 变更明细、裁决理由与门禁证据见 **`CHANGES.md`**；修复前历史数字见 `BASELINE.md`（故意不改）。
>
> 下面「这个 PR 做了什么」记录的是 PR1 的搬迁范围，保留作为结构说明。

## 这个 PR 做了什么

| 来源 | 文件 | 内容 |
|---|---|---|
| §4.2 + §4.2.1 | `src/http-client.ts` | `HttpError` / `commonHeaders` / `httpJson` / `httpStream` |
| §4.4 | `src/queue.ts` | `KeyRotator` / `TranslateQueue` / `priorityOf` |
| §4.4 | `src/cache.ts` | `LruSet` / `glossaryScopeKey` / `cacheKey` / `globalGlossaryVersion` |
| §12.5 | `src/types.ts` | `TranslateOpts` / `ApiCaps` / `TranslatorProvider` 等 |
| §12.5 | `src/engine.ts` | `normalizeContext` / `selectRoute` / `HunyuanEngine` |

**机械调整（不算逻辑改动，逐条列出以便 review）**

1. 补 `export` —— 文档片段是散落的，进模块必须导出。
2. §4.2 与 §4.2.1 原属同一个 `http-client.ts`，合并为一个模块；`import https` 只保留一份。
3. 原文 `import type http from 'node:http'; let req!: http.ClientRequest` → 改为从 `node:https` 导入 `ClientRequest` 类型（沙盒 shims 只在该模块声明它）。
4. 新增 `src/runtime.ts` / `src/env.ts` / `shims/node.d.ts`：文档里被引用但没有实现的外部符号（diagnostics、viewManager、settings、md5、buildContext、CA_POOL、BASE、keyRotator、translateQueue、Node API 类型）。**全部是占位，每个都在 BASELINE.md 登记。**
5. PR1 时未补任何"看起来该补"的东西：例如 `HunyuanEngine` 调用了 `this.buildMessages` 但类里没有该方法 —— 当时保留，让编译器报出来（**PR2 已修**，见 `CHANGES.md`）。

**PR2 做了**：`TranslateOpts` 补 2 个字段、`buildMessages` 接入、`penalize` 补参数、`KeyRotator` 加 `?? null`、更新测试与基线。仅此 5 处。

**PR3 做了**：`applyBackpressure` 比较符、`onStable` 接线、in-flight 去重、round-robin + `perAccountCap`，全部只动 `src/queue.ts`。

**仍然没做**（PR4+）：`cacheKey` 补 `context`/`style` + `cache_version` 迁移 + 缓存表禁存 `src_text` 明文（PR4）、`http-client` 的 deadline/响应体上限/3xx/aborted（PR5）、`Bearer null` 收窄 + `normalizeContext` 接线 + `buildMessages` 真实实现（PR6）、T10 加密、接真实 SQLite/诊断面板、§0 七项实测。

**已裁决不再做**：补 `accountId`（见 `CHANGES.md` 矛盾 A）——`global` 译文跨账号共享是设计意图。

## 怎么跑（无需 npm install）

项目自带 TypeScript 5.6.3 编译器（`tools/ts/lib/`），Node ≥ 20 即可：

```bash
node tools/ts/lib/tsc.js --noEmit -p tsconfig.json   # 真实 tsc --noEmit
node scripts/typecheck-gate.mjs                       # 基线门禁（首次生成 baseline/tsc-errors.txt）
node scripts/build.mjs                                # 编译到 dist/（容忍存量类型错误）
node --test dist/test/*.test.js                       # 单测
```

本机若装了 npm 依赖，等价命令：`npm run check`。

## 门禁设计（§8.1）

| 层 | 位置 | 阻断 |
|---|---|---|
| 类型检查 | `scripts/typecheck-gate.mjs` | ✅ 错误集合**不得新增**（不是「零错误」） |
| 单测 / 集成 | `test/characterization.test.ts` | ✅ CI 阻断 |
| 待修缺陷清单 | `test/pending.test.ts` | ❌ 全为 `todo`，不阻断 |
| 真机 / 长稳（74 / 79 / 85） | 发布检查单 | ❌ 不进 CI |

> 「零错误门禁」在存量错误存在时等于没有门禁——pipeline 会被跳过或永久标红。改成基线比对后，每次修复或劣化都必须显式更新 `baseline/tsc-errors.txt`，进 PR 记录。

## 目录

```
delai-core-pr1/
├── src/            # 搬迁后的核心代码
├── test/           # 现状固化测试 + 待修缺陷 todo
├── shims/          # 最小 Node 类型声明（无 @types/node 时）
├── scripts/        # 基线门禁
├── tools/ts/lib/   # 离线 TypeScript 编译器 + 标准库
├── baseline/       # tsc 错误基线（PR2 后为 0 条，空文件）
├── BASELINE.md     # PR1 时点的真实编译/测试数字（历史快照，不改）
├── CHANGES.md      # PR1 / PR2 变更记录与 revert 对照
└── .github/workflows/core.yml
```

## 与文档的关系

- `plan-v1.8.md`：冻结，未改动。
- `decision-q1-tos.md` v1.3：已冻结，未改动。
- `s3-env-baseline.md`：已收口，未改动。
- 本目录**不是第四份方案**，是代码仓库的第一个 PR 工作区。
