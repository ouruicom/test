# 变更记录（便于 revert 对照）

> 每个 PR 单独一节、只做一件事（§8.2）。`BASELINE.md` 是 **PR1 时点的历史快照，故意不改**——
> 留着它才能对照出「修复前 / 修复后」的真实数字差异。

---

## PR1 · 纯搬迁 + 基线（已完成）

把 `plan-v1.8.md` 的 §4.2 / §4.2.1 / §4.4 / §12.5 TS 片段搬进 `src/`，不改逻辑。

- `tsc --noEmit`：**5 条存量错误**
- 单测：**28 / 12 pass / 0 fail / 16 todo**
- 运行时新发现 3 条缺陷（队列 in-flight 去重失效、`buildBody` 抛错、CI 退出码 2）
- 详见 `BASELINE.md`

---

## PR2 · 修 5 条编译期错误，基线清零（当前版本）

**范围**：只修「不能编译」，不改任何业务行为。P0 系列逻辑缺陷一律留到 PR3–PR6。

### 改了 5 处

| # | 文件 | 改动 | 关闭 |
|---|---|---|---|
| 1 | `src/types.ts` | `TranslateOpts` 补 `customerGlossaryHit?: boolean` / `wantOfficialContext?: boolean`。两个字段是 §12.5 `selectRoute()` 第 2713/2715 行**已经在读、但接口漏声明**的；声明为可选，缺省时 falsy，路由行为与 PR1 完全一致 | P1-3（TS2339 ×2） |
| 2 | `src/engine.ts` | `this.buildMessages(o, text)` → 导入的 `buildMessages(o, text)`（`runtime.ts` 已有占位） | P1-5（TS2339）+ PR1 运行时新发现② |
| 3 | `src/engine.ts` | 把 `keyRotator.next()` 提取成 `const token`，catch 里 `keyRotator.penalize(token)` 补上必填参数（原文把参数写成注释占位） | TS2554 |
| 4 | `src/queue.ts` | `return k` → `return k ?? null`。`noUncheckedIndexedAccess` 下数组下标可能是 `undefined`；取模保证在范围内，`?? null` 是纯类型兜底 | TS2322 |
| 5 | 测试与基线 | `buildBody` 的 `throws` 固化断言改为「返回 messages 数组」；新增 1 条 `selectRoute` 用例验证两个新字段确实参与回退判定；关闭 3 条 todo；`baseline/tsc-errors.txt` 清空 | 关闭证据 |

> **没顺手改的**：`Bearer ${token}` 在 token 为 null 时仍会发出 `"Bearer null"`（P0-3，tsc 不报，留 PR6）；`normalizeContext()` 仍零调用（P1-4，留 PR4/PR6）；`buildMessages` 仍是返回 `[]` 的占位。
> **所以 PR2 之后引擎依然不能真正发翻译请求**——编译通过 ≠ 功能可用，这点必须写清楚。

### 门禁两阶段实测（这是本 PR 最有价值的证据）

旧基线还在时直接跑门禁，它**拒绝通过**并精确列出消失的 5 条：

```
[gate] 基线发生变化：新增 0 条，消失 5 条
  - src/engine.ts(29,40): error TS2339: Property 'customerGlossaryHit' ...
  - src/engine.ts(31,9): error TS2339: Property 'wantOfficialContext' ...
  - src/engine.ts(48,26): error TS2339: Property 'buildMessages' ...
  - src/engine.ts(76,62): error TS2554: Expected 1-2 arguments, but got 0.
  - src/queue.ts(23,5): error TS2322: Type 'string | undefined' ...
[gate] 请确认是「修复」还是「劣化」，然后更新 baseline/tsc-errors.txt 再提交。
退出码 1
```

清空基线后复跑：`[gate] PASS：错误集合与基线一致（0 条存量错误）`。

> 这证明 `typecheck-gate.mjs` 不是摆设：它同时能挡住「新增错误」和「悄悄改了代码却没更新基线」。

### 数字对照

| 项 | PR1 | PR2 |
|---|---|---|
| `tsc --noEmit` | 5 条错误 | **0 条，退出码 0** |
| 基线门禁 | PASS（5 条） | PASS（0 条） |
| 单测 | 28 / 12 pass / 16 todo | **26 / 13 pass / 0 fail / 13 todo** |
| 静态扫描（无 `autoSend`） | PASS | PASS |

> 总数从 28 降到 26 是故意的：3 条已关闭的 todo 从清单移除，1 条新用例加进 characterization。
> pass 12 → 13、todo 16 → 13，正好对得上。

### review 怎么核

```bash
node tools/ts/lib/tsc.js --noEmit -p tsconfig.json   # 应当无任何输出、退出码 0
node scripts/typecheck-gate.mjs                       # PASS（0 条）
node scripts/build.mjs                                # PASS
node --test dist/test/*.test.js                       # 13 pass / 0 fail / 13 todo
```

想 revert 到修复前：取仓库里的 `delai-core-pr1.zip`（PR1 快照），或 `git revert` 本 PR 的 5 处改动 + 恢复 `baseline/tsc-errors.txt` 那 5 行。

---

## 决策记录：BASELINE.md §5 矛盾 A 已裁决（用户拍板，2026-11-03）

> `plan-v1.8.md` §4.4 第 1179 行：「key 不含 account_id，跨账号共享**符合预期**」
> vs `decision-q1-tos.md` v1.2/v1.3：把「不含 accountId」定性为**真漏网 + 隐私问题**，T9.6 要求补键。

### 结论

**不补 `accountId`，保持 `scope=global` 译文跨账号共享。** 以 `plan-v1.8.md` §4.4 的口径为准。

### 理由

1. **补键会废掉 R18「高频话术秒回」**：8 个号收到同一句 "MOQ?" 就得各翻一次，缓存命中率掉到 1/8，预热 Top 2000 也失去跨号意义。
2. **客户级术语本来就没串**：`glossaryScopeKey(scope)` 对 `customer:<peer_id>` 已按客户隔离；能跨号共享的只有 `global` 通用译文，不含客户专属信息。
3. **真正的「串味」是 P0-2，不是 accountId**：同一句 "please confirm" 在催发货/报价两个上下文拿到同一译文，是因为 key 漏了 `context` / `style`。补 accountId 是打错靶子。
4. **真正的隐私面在落盘，不在 key**：译文缓存按 Q3 决策本就不加密，那是 T10.2 用「备份排除缓存表 / 清理 `-wal` `-shm`」处理的，跟键里有没有账号 ID 无关。补键只防住「能推断另一个号也收到过这句话」这个极弱的侧信道，却要付 8 倍缓存与预热、旧缓存全量失效、T9.6 整条迁移的代价。

### 偏离声明

- 本结论**偏离** `decision-q1-tos.md` v1.2「全局单例清单」里把缓存键定性为「本轮唯一新缺陷」、以及 v1.3 T9.6「键补 accountId」的表述。
- 按用户选定口径：**不改已冻结的 `plan-v1.8.md` / `decision-q1-tos.md` v1.3 / `s3-env-baseline.md`，不再送文心评审**；本记录就是裁决留档。
- 对应改动落在代码层：`test/pending.test.ts` 的「v1.3 新缺陷」与用例 84 在 PR4 改写。

### PR4 口径随之调整

| 原计划 | 新口径 |
|---|---|
| 补 `accountId` → 跨号不命中 | **不补**；`global` 共享是设计意图 |
| 用例 84「B 号不命中 A 号缓存」 | 改为「`global` 可跨号命中；`customer:<peer>` 不串」 |
| T9.6 因补键触发全量失效 | **仍然需要 `cache_version`**：因为 PR4 补 `context`/`style` 进 key 同样会让旧缓存全量失效；触发原因变了，迁移机制不变 |
| 隐私约束 | 新增硬约束：**缓存表只存 `dst_text` 与 key 哈希，绝不存 `src_text` / `last_msg_preview` 明文**（真正的隐私口在这里堵） |

---

## PR3 · 队列层 4 条缺陷（当前版本）

**范围**：只动 `src/queue.ts` 与对应测试，不碰缓存 / 引擎 / HTTP。矛盾 A 的裁决不影响本 PR，故按 §8.2 顺序先跑。

### 关闭 4 条

| # | 改动 | 关闭 |
|---|---|---|
| 1 | `push()` 判重同时检查 `this.inflight`（Set）与队列残留；`pump()` 出队时 add、finally 时 delete | PR1 运行时新发现① |
| 2 | `applyBackpressure()` 排序改为 `a.priority - b.priority \|\| b.enqueuedAt - a.enqueuedAt`（**保留优先级**：P0 在前、同优先级新的在前），尾部才 splice 掉 | P0-1 |
| 3 | `pump()` 里仅在 `run()` **成功**时 `this.onStable()`；两参 `then` 顺手接住 rejection，避免原 `run().finally()` 产生 unhandled rejection | P0-4 |
| 4 | `pickNext()` 跨账号 round-robin + 账号内优先级/FIFO；`push()` 加 `perAccountCap`（默认 25，构造第 4 参数可配），超限计 `translate.dropped.perAccountCap` | T9.5 |

> **辨析保留**：队列本体仍是全局单例（`maxConcurrent` 由 §0 第 4 项实测的 API QPS 决定），按账号拆的是**入队配额与调度**，不是队列自己——这是 v1.3 §5 修正 2 的落地。
> **两处排序目的不同**，别再合并：`applyBackpressure` 排的是「谁该被保留」，`pickNext` 排的是「谁先出队」。

### 门禁又一次抓到问题

写测试时漏了 `Priority` 类型导入，门禁立刻报「新增 2 条 TS2304，退出码 1」并拒绝通过；补上导入后 `PASS（0 条）`。这是继 PR2 之后第二次实测证明基线门禁不是摆设。

### 数字对照

| 项 | PR1 | PR2 | PR3 |
|---|---|---|---|
| `tsc --noEmit` | 5 条 | 0 条 | **0 条** |
| 基线门禁 | PASS(5) | PASS(0) | PASS(0) |
| 单测 | 28 / 12 pass / 16 todo | 26 / 13 pass / 13 todo | **25 / 17 pass / 0 fail / 8 todo** |

> PR3 的 todo 从 9 再降到 8：本包同时落档「矛盾 A 用户裁决」——不补 `accountId` 后，那条「v1.3 新缺陷」不再是缺陷，从清单移除（留注释存档）。代码修复与决策裁决两件事都只动测试清单 / `CHANGES.md`，不触碰业务代码。
| 静态扫描 | PASS | PASS | PASS |

新增/改写 5 条 characterization 用例：in-flight 合并（5→4 次执行）、210 条堆积下 50 条 P0 一条不丢、onStable spy（2 成功 2 次 / 1 失败 0 次）、round-robin（`order[1] === 'a8'`）、perAccountCap=3 只放 3 条。

### review 怎么核

```bash
node tools/ts/lib/tsc.js --noEmit -p tsconfig.json   # 无输出，退出码 0
node scripts/typecheck-gate.mjs                       # PASS（0 条）
node scripts/build.mjs                                # PASS
node --test dist/test/*.test.js                       # 17 pass / 0 fail / 8 todo
```

---

## 下一个：PR4（建议，未开工）

按新裁决的口径做 `src/cache.ts`：`cacheKey` 补 `context` / `style`（**不补 accountId**）、`cache_version` 迁移与重新预热、缓存表禁存 `src_text` 明文、改写用例 84。

**仍未拍板的工程项**：`buildMessages` 真实实现（当前返回 `[]` 占位）、§0 七项实测、S2/S3 真机数据——都不挡 PR4。
