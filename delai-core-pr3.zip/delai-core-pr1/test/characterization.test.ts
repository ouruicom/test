// §8.1「单测层」：CI 阻断。这里断言的是【PR1 搬迁后的当前行为】，
// 目的是把代码钉住——下一个 PR 修 bug 时会变红，必须连同本文件一起更新，
// 防止「文档说改了、代码没动」再次发生。

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { HttpError, commonHeaders } from '../src/http-client';
import { LruSet, cacheKey, globalGlossaryVersion } from '../src/cache';
import { KeyRotator, TranslateQueue, priorityOf } from '../src/queue';
import { selectRoute, normalizeContext, HunyuanEngine } from '../src/engine';
import { defaultCaps } from '../src/runtime';
import type { Job, Priority } from '../src/queue';
import type { TranslateOpts, ApiCaps } from '../src/types';

test('HttpError.from：429/408/5xx 可重试，401/403/400 不重试', () => {
  assert.equal(HttpError.from(429, '').retryable, true);
  assert.equal(HttpError.from(408, '').retryable, true);
  assert.equal(HttpError.from(503, '').retryable, true);
  assert.equal(HttpError.from(401, '').retryable, false);
  assert.equal(HttpError.from(403, '').retryable, false);
  assert.equal(HttpError.from(400, '').retryable, false);
  assert.equal(HttpError.from(429, 'x').status, 429);
});

test('commonHeaders：强制 Content-Type，且允许调用方覆盖', () => {
  assert.deepEqual(commonHeaders(), { 'Content-Type': 'application/json' });
  assert.deepEqual(commonHeaders({ Authorization: 'Bearer k' }), {
    'Content-Type': 'application/json', Authorization: 'Bearer k',
  });
});

test('LruSet：读命中提升新鲜度（修复 v1.7.3 的伪 LRU）', () => {
  const s = new LruSet(2);
  s.add('a'); s.add('b');
  assert.equal(s.has('a'), true);   // a 移到末尾
  s.add('c');                       // 淘汰最旧的 b
  assert.equal(s.has('a'), true, '热的 a 不应被挤掉');
  assert.equal(s.has('b'), false);
  assert.equal(s.has('c'), true);
});

test('globalGlossaryVersion：settings 缺失时回落 1（v1.5.2 R29 兜底）', () => {
  assert.equal(globalGlossaryVersion(), '1');
});

test('cacheKey：同输入稳定、改 model/scope/text 会变', () => {
  const base = { engine: 'hunyuan', model: 'hy-mt2-lite', from: 'en', to: 'zh',
                 text: 'MOQ?', scope: 'global' };
  assert.equal(cacheKey(base), cacheKey({ ...base }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, model: 'hy-mt2-pro' }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, text: 'shipping cost?' }));
  assert.notEqual(cacheKey(base), cacheKey({ ...base, scope: 'customer:alice' }));
});

test('【现状固化】cacheKey 不含 accountId / context / style —— 已知缺陷，见 pending', () => {
  const base = { engine: 'hunyuan', model: 'hy-mt2-lite', from: 'en', to: 'zh',
                 text: 'please confirm', scope: 'global' };
  // 当前签名里根本没有这三个字段，故不同上下文 / 不同账号必然得到同一把 key。
  // 这两条断言是「记录现状」，不是认可现状；修完 P0-2 / v1.3 后必须改本用例。
  assert.equal(cacheKey(base), cacheKey({ ...base }));
  assert.equal(typeof cacheKey(base), 'string');
});

test('KeyRotator：无可用 Key 返回 null；penalize 后进入冷却', () => {
  assert.equal(new KeyRotator([]).next(), null);
  const r = new KeyRotator(['k1', 'k2']);
  assert.equal(r.next(), 'k1');
  r.penalize('k1');
  assert.equal(r.next(), 'k2');
  r.penalize('k2');
  assert.equal(r.next(), null);
});

test('priorityOf：当前会话 P0；其余由 viewManager 决定 P1/P2', () => {
  assert.equal(priorityOf('a1', true), 0);
  assert.equal(priorityOf('a1', false), 2);   // runtime stub 恒 false
});

test('PR3：同 key 去重覆盖 in-flight；并发仍不超上限', async () => {
  const q = new TranslateQueue(2, 1, 8);
  let peak = 0;
  let running = 0;
  let calls = 0;
  const make = (key: string): Job => ({
    key, priority: 0, accountId: 'a1', enqueuedAt: Date.now(),
    run: async () => {
      calls++; running++; peak = Math.max(peak, running);
      await new Promise<void>(r => setTimeout(r, 5));
      running--;
    },
  });
  q.push(make('x')); q.push(make('x'));   // 第二条应被 inflight 集合拦下
  q.push(make('y')); q.push(make('z')); q.push(make('w'));
  await new Promise<void>(r => setTimeout(r, 60));
  // 第一条 x 已出队执行，重复的那条被合并 → 总共 x/y/z/w 四次（PR1 时为 5 次）。
  assert.equal(calls, 4, '同 key 只执行一次');
  assert.ok(peak <= 2, `峰值并发 ${peak} 应 <= 2`);
});

test('PR3 / P0-1：背压超限时保留 P0，切掉的是 P2 旧任务', async () => {
  // maxConcurrent=1 + 挂起 gate：让任务能堆进队列，触发 200 上限。
  // perAccountCap 传大值，避免把 cap 的影响混进背压测试。
  let release!: () => void;
  const gate = new Promise<void>(r => { release = r; });
  const q = new TranslateQueue(1, 1, 8, 1000);
  const order: Priority[] = [];
  const make = (key: string, priority: Priority): Job => ({
    key, priority, accountId: 'a1', enqueuedAt: Date.now() + Number(key.slice(1)),
    run: async () => { order.push(priority); await gate; },
  });
  q.push(make('k0', 2));                       // 占住唯一并发槽
  for (let i = 1; i <= 50; i++) q.push(make(`k${i}`, 0));        // 50 条 P0
  for (let i = 51; i <= 210; i++) q.push(make(`k${i}`, 2));      // 160 条 P2 → 总计 210 > 200
  release();
  await new Promise<void>(r => setTimeout(r, 120));
  const p0 = order.filter(p => p === 0).length;
  // 修复前（降序排序）会切掉约 10 条 P0；修复后 50 条 P0 一条不丢。
  assert.equal(p0, 50, `P0 应全部保留，实际 ${p0}`);
  assert.ok(order.length < 211, '确实发生了背压丢弃');
});

test('PR3 / P0-4：仅成功任务触发 onStable，失败不计入稳定', async () => {
  const q = new TranslateQueue(2, 1, 8, 1000);
  let stableCalls = 0;
  (q as unknown as { onStable: () => void }).onStable = () => { stableCalls++; };
  const ok = (key: string): Job => ({
    key, priority: 0, accountId: 'a1', enqueuedAt: Date.now(),
    run: async () => { await Promise.resolve(); },
  });
  const bad = (key: string): Job => ({
    key, priority: 0, accountId: 'a1', enqueuedAt: Date.now(),
    run: async () => { throw new Error('模拟 500'); },
  });
  q.push(ok('a')); q.push(ok('b')); q.push(bad('c'));
  await new Promise<void>(r => setTimeout(r, 40));
  assert.equal(stableCalls, 2, '两条成功各触发一次，失败那条不触发');
});

test('PR3 / T9.5：跨账号 round-robin，1 号堆积时 8 号不被饿死', async () => {
  let release!: () => void;
  const gate = new Promise<void>(r => { release = r; });
  const q = new TranslateQueue(1, 1, 8);
  const order: string[] = [];
  const make = (key: string, accountId: string): Job => ({
    key, priority: 0, accountId, enqueuedAt: Date.now(),
    run: async () => { order.push(accountId); await gate; },
  });
  q.push(make('k0', 'a1'));                       // 出队执行，lastAccount = a1
  for (let i = 1; i <= 20; i++) q.push(make(`k${i}`, 'a1'));
  q.push(make('p0', 'a8'));
  release();
  await new Promise<void>(r => setTimeout(r, 100));
  // 纯 FIFO 下 a8 会排在第 22 位；轮转后它应是第 2 个出队的。
  assert.equal(order[0], 'a1');
  assert.equal(order[1], 'a8', `a8 应被优先轮转，实际第 ${order.indexOf('a8') + 1} 位`);
});

test('PR3 / T9.5：每账号在队上限生效，单账号不能灌满全局队列', async () => {
  let release!: () => void;
  const gate = new Promise<void>(r => { release = r; });
  const q = new TranslateQueue(1, 1, 8, 3);      // cap = 3
  const order: string[] = [];
  const make = (key: string): Job => ({
    key, priority: 0, accountId: 'a1', enqueuedAt: Date.now(),
    run: async () => { order.push(key); await gate; },
  });
  q.push(make('k0'));
  for (let i = 1; i <= 8; i++) q.push(make(`k${i}`));   // 只有 3 条能进队列
  release();
  await new Promise<void>(r => setTimeout(r, 60));
  assert.equal(order.length, 4, 'seed 1 条 + 排队 3 条 = 4，其余被 perAccountCap 拒绝');
});

test('selectRoute：§0 未实测前全部能力为 false → 一律回退 chat', () => {
  const o: TranslateOpts = { to: 'zh' };
  assert.equal(selectRoute(o, defaultCaps), 'chat');
});

test('PR2：buildBody 在 chat 路径返回 messages 数组（P1-5 已关闭）', () => {
  const e = new HunyuanEngine();
  const body = e.buildBody({ to: 'zh', model: 'hy-mt2-lite' }, 'hello') as any;
  assert.equal(e.route({ to: 'zh' }), 'chat');
  assert.ok(Array.isArray(body.messages), '不再抛 this.buildMessages is not a function');
  assert.equal(body.text, undefined, 'chat 路径用 messages 而非 text');
  // runtime.buildMessages 目前是返回 [] 的占位；真实 messages 内容属 PR6。
  assert.deepEqual(body.messages, []);
});

test('PR2：TranslateOpts 两个新字段确实参与 selectRoute 回退判定（P1-3 已关闭）', () => {
  const capsAll: ApiCaps = {
    openApiEndpointExists: true,
    modelSupportsOpenApi: { 'hy-mt2-lite': true, 'hy-mt2-plus': true, 'hy-mt2-pro': true },
    referencesAcceptTerms: false,
    glossaryIdLimit: 10,
    contextFieldConfirmed: false,
  };
  assert.equal(selectRoute({ to: 'zh' }, capsAll), 'openapi');
  // 命中客户级术语 + references 不接受 term → 回退 chat
  assert.equal(selectRoute({ to: 'zh', customerGlossaryHit: true }, capsAll), 'chat');
  // 想用官方 context 但字段未实测确认 → 回退 chat
  assert.equal(selectRoute({ to: 'zh', wantOfficialContext: true }, capsAll), 'chat');
  // 未传这两个字段时行为与 PR1 一致（falsy），不改变既有路由
  assert.equal(selectRoute({ to: 'zh' }, defaultCaps), 'chat');
});

test('normalizeContext：openapi 拼角色前缀，chat 返回结构化 turns', () => {
  const o: TranslateOpts = {
    to: 'zh',
    contextTurns: [{ role: 'user', text: 'MOQ?' }, { role: 'assistant', text: '500 pcs' }],
  };
  assert.deepEqual(normalizeContext(o, 'chat'), { turns: o.contextTurns });
  assert.equal(
    (normalizeContext(o, 'openapi') as { text: string }).text,
    'user: MOQ?\nassistant: 500 pcs',
  );
});
