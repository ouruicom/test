// §8.1：本文件全部为 TODO 用例，CI 不因它们失败，但「缺陷清单」随代码一起版本化。
// 每修一条：去掉对应 todo、在 characterization.test.ts 里改成【正确行为】断言、
// 更新 baseline/tsc-errors.txt —— 形成从「记录」到「关闭」的可审计路径。
// 已关闭项保留一行注释存档，便于 review 时对照，不参与测试计数。
//
// 编号沿用文心 rev.2 的 P0/P1 与 decision-q1-tos.md v1.3 的 T9.x。
// PR2 状态：关闭 3 条（P1-3 / P1-5 / PR1 运行时新发现②），剩余 13 条 TODO。
// PR3 状态：关闭 4 条（P0-1 / P0-4 / T9.5 / PR1 运行时新发现①）→ 剩 9 条；
//    同包落档「矛盾 A 用户裁决」（不补 accountId），再移除 1 条非缺陷 TODO → **剩 8 条**。
//    两次变更性质不同（代码修复 / 决策裁决），但都只改测试清单与 CHANGES.md，不动业务代码。

import { test } from 'node:test';

const TODO = (why: string) => ({ todo: why });

// ✅ P0-1 已于 PR3 关闭：applyBackpressure 改「保留优先级」升序 + 时间降序，
//    characterization 新增「210 条堆积，50 条 P0 一条不丢」用例。

test('P0-2 cacheKey 漏 context / style：不同上下文与风格命中同一旧译文',
  TODO('cache.ts：键补 contextDigest 与 style；用例 28'),
  () => { /* 修后断言：同 text 不同 context/style → 不同 key */ });

test('P0-3 全熔断时发出 "Bearer null"；需显式抛 AuthError 且出站函数不被调用',
  TODO('engine.ts call()：next(): string|null 收窄；用例 68。注意 tsc 抓不到模板插值 null'),
  () => { /* 修后断言：httpJson/httpStream 未被调用 + UI 收到 quotaExhausted（不是「且返回 401」） */ });

// ✅ P0-4 已于 PR3 关闭：pump() 中仅成功任务调用 onStable()，失败不计稳定；
//    characterization 用 spy 断言「2 成功 → 2 次，1 失败 → 0 次」。
//    ⚠️ 仍待 §0 第 4 项实测后校准 60s 门槛与 ceiling，属发布检查单，不是缺陷。

test('P1-1 已 abort 的 AbortSignal 传入 httpJson 仍会发出请求',
  TODO('http-client.ts：请求前检查 signal.aborted；用例未编号'),
  () => { /* 修后断言：不发起 https.request */ });

test('P1-2 httpJson 无绝对 deadline / 无响应体上限 / 3xx 未处理',
  TODO('http-client.ts：补 deadline + maxResponseBytes + 3xx 显式失败；C-1 只修了流式一半'),
  () => { /* 修后断言：超大响应体截断、302 不当 JSON 解析、心跳不拖死 */ });

// ✅ P1-3 已于 PR2 关闭：TranslateOpts 补两个字段，基线错误清零，
//    characterization.test.ts 新增「两个字段参与 selectRoute 判定」用例。
// ✅ P1-5 已于 PR2 关闭：this.buildMessages → 导入的 buildMessages，运行时不再抛错。

test('P1-4 normalizeContext() 定义但零调用；contextText / contextTurns 均未进请求体',
  TODO('engine.ts：buildBody 按 route 分派调用 normalizeContext'),
  () => { /* 修后断言：openapi body 含拼接后的 context 字段 */ });

// ⚖️ 2026-11-03 用户裁决（见 CHANGES.md「矛盾 A」）：不补 accountId，
//    global 译文跨账号共享是设计意图（plan-v1.8 §4.4）。本条不再视为缺陷，
//    故从 TODO 清单移除；PR4 会把用例 84 改写为「global 可跨号命中 / customer 级不串」。
//    隐私面改由「缓存表禁存 src_text 明文」+ T10.2 备份清理处置。

// ✅ T9.5 已于 PR3 关闭：pickNext() 跨账号轮转 + 账号内优先级/FIFO，
//    push() 加 perAccountCap（默认 25，构造可配）；characterization 两条用例分别验证。

test('T9.6 补 accountId 后旧缓存全量失效，缺 cache_version 迁移与重新预热',
  TODO('推荐「键 + 版本号」，不推荐按账号分库（与 §4.7.1 单连接 + WAL 约束冲突）；用例 87'),
  () => { /* 修后断言：升级后无跨号命中且高频话术秒回不退化 */ });

// ✅ 【PR1 运行时新发现①】已于 PR3 关闭：inflight Set 覆盖正在执行的键，
//    push() 判重同时检查队列与 inflight；characterization 断言 calls 5 → 4。

// ✅ 【PR1 运行时新发现②】已于 PR2 关闭：buildBody 返回 messages 数组（占位为 []），
//    characterization.test.ts 已把 throws 断言改成 Array.isArray 断言。

test('T1 出站「预览确认」尚未落到代码：autoSend 静态扫描用例 73 未实现',
  TODO('PR 后续：全局搜索配置无 autoSend/autoSubmit 入口'),
  () => { /* 静态扫描 */ });

test('T10.1 / T10.2 字段级加密、safeStorage backend 白名单、-wal/-shm 清理策略',
  TODO('涉及 SQLite/safeStorage，属集成层（§8.1 集成层），不在 packages/core 单测范围'),
  () => { /* 集成测试 */ });
